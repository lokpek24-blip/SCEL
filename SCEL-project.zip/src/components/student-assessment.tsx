"use client";

import Image from "next/image";
import Link from "next/link";
import { useMemo, useState } from "react";
import { DEMO_MODE_LABEL, ECO_ITEMS, SCIENCE_QUESTIONS, USABILITY_ITEMS } from "@/data/instruments";
import { type AttemptState, type Participant, readDemoStore, writeDemoStore } from "@/lib/demo-store";

export type StudentView =
  | "identity"
  | "instructions"
  | "question"
  | "phet"
  | "eco"
  | "usability"
  | "review"
  | "summary";

const defaultIdentity = {
  nameOrInitial: "",
  participantCode: "",
  school: "",
  className: "",
  consent: false,
};

export default function StudentAssessment({ initialView = "identity" }: { initialView?: StudentView }) {
  const [view, setView] = useState<StudentView>(initialView);
  const [attempt, setAttempt] = useState<AttemptState | null>(() => {
    if (typeof window === "undefined") return null;
    const store = readDemoStore();
    return store.attempts[0] ?? null;
  });
  const [identity, setIdentity] = useState(() => {
    if (typeof window === "undefined") return defaultIdentity;
    const store = readDemoStore();
    const currentParticipant = store.participants[0];
    if (!currentParticipant) return defaultIdentity;
    return {
      nameOrInitial: currentParticipant.nameOrInitial,
      participantCode: currentParticipant.participantCode,
      school: currentParticipant.school,
      className: currentParticipant.className,
      consent: currentParticipant.consent,
    };
  });
  const [questionIndex, setQuestionIndex] = useState(1);
  const [saveStatus, setSaveStatus] = useState<"idle" | "saving" | "saved" | "error">("idle");
  const [message, setMessage] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const currentQuestion = SCIENCE_QUESTIONS.find((question) => question.number === questionIndex) ?? SCIENCE_QUESTIONS[0];

  const persistAttempt = (nextAttempt: AttemptState) => {
    const store = readDemoStore();
    const index = store.attempts.findIndex((item) => item.id === nextAttempt.id);
    if (index >= 0) {
      store.attempts[index] = nextAttempt;
    } else {
      store.attempts.push(nextAttempt);
    }
    writeDemoStore(store);
  };

  const unansweredScientific = useMemo(() => {
    if (!attempt) return [];
    return SCIENCE_QUESTIONS.filter(
      (question) => !attempt.scientificResponses[question.number]?.trim(),
    ).map((question) => question.number);
  }, [attempt]);

  const unansweredEco = useMemo(() => {
    if (!attempt) return [];
    return ECO_ITEMS.filter((item) => attempt.ecoResponses[item.id] === undefined).map((item) => item.id);
  }, [attempt]);

  const unansweredUsability = useMemo(() => {
    if (!attempt) return [];
    return USABILITY_ITEMS.filter((item) => attempt.usabilityResponses[item.id] === undefined).map((item) => item.id);
  }, [attempt]);

  const persistProgress = (nextAttempt: AttemptState) => {
    setSaveStatus("saving");
    try {
      persistAttempt(nextAttempt);
      setSaveStatus("saved");
      setMessage("");
      return true;
    } catch {
      setSaveStatus("error");
      setMessage("Jawaban belum berhasil disimpan di browser ini. Periksa penyimpanan browser, lalu coba lagi.");
      return false;
    }
  };

  const handleIdentitySubmit = () => {
    const cleanCode = identity.participantCode.trim();
    const cleanName = identity.nameOrInitial.trim();
    const cleanSchool = identity.school.trim();
    const cleanClass = identity.className.trim();

    if (!cleanName || !cleanCode || !cleanSchool || !cleanClass) {
      setMessage("Harap lengkapi semua field identitas sebelum melanjutkan.");
      return;
    }

    if (!identity.consent) {
      setMessage("Anda harus menyetujui prosedur asesmen agar dapat melanjutkan.");
      return;
    }

    const store = readDemoStore();
    const existingParticipant = store.participants.find(
      (item) => item.participantCode.toLowerCase() === cleanCode.toLowerCase(),
    );

    if (existingParticipant) {
      const existingAttempt = store.attempts.find((item) => item.participantId === existingParticipant.id);
      setAttempt(
        existingAttempt ?? {
          id: `attempt-${Date.now()}`,
          participantId: existingParticipant.id,
          participantCode: existingParticipant.participantCode,
          status: "in_progress",
          startedAt: new Date().toISOString(),
          lastSavedAt: new Date().toISOString(),
          scientificResponses: {},
          drawingResponses: {},
          ecoResponses: {},
          usabilityResponses: {},
          usabilityOpen: { mostHelpful: "", encounteredProblems: "" },
        },
      );
      setIdentity({
        nameOrInitial: existingParticipant.nameOrInitial,
        participantCode: existingParticipant.participantCode,
        school: existingParticipant.school,
        className: existingParticipant.className,
        consent: existingParticipant.consent,
      });
      setView("instructions");
      setMessage("Sesi peserta ditemukan dan dilanjutkan.");
      return;
    }

    const newParticipant: Participant = {
      id: `participant-${Date.now()}`,
      participantCode: cleanCode,
      nameOrInitial: cleanName,
      school: cleanSchool,
      className: cleanClass,
      consent: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    const newAttempt: AttemptState = {
      id: `attempt-${Date.now()}`,
      participantId: newParticipant.id,
      participantCode: cleanCode,
      status: "in_progress",
      startedAt: new Date().toISOString(),
      lastSavedAt: new Date().toISOString(),
      scientificResponses: {},
      drawingResponses: {},
      ecoResponses: {},
      usabilityResponses: {},
      usabilityOpen: { mostHelpful: "", encounteredProblems: "" },
    };

    const nextStore = readDemoStore();
    nextStore.participants.push(newParticipant);
    nextStore.attempts.push(newAttempt);
    writeDemoStore(nextStore);
    setAttempt(newAttempt);
    setView("instructions");
    setMessage("");
  };

  const updateScientificAnswer = (value: string) => {
    if (!attempt) return;
    const nextAttempt = {
      ...attempt,
      scientificResponses: { ...attempt.scientificResponses, [questionIndex]: value },
      lastSavedAt: new Date().toISOString(),
    };
    setAttempt(nextAttempt);
    persistProgress(nextAttempt);
  };

  const uploadDrawing = (questionNumber: number, file?: File) => {
    if (!attempt || !file) return;
    if (!["image/png", "image/jpeg"].includes(file.type)) {
      setMessage("Format gambar yang didukung adalah PNG atau JPG.");
      return;
    }
    if (file.size > 1_000_000) {
      setMessage("Ukuran gambar maksimal 1 MB agar dapat disimpan di browser.");
      return;
    }

    const reader = new FileReader();
    reader.onerror = () => setMessage("Gambar gagal dibaca. Coba pilih file lain.");
    reader.onload = () => {
      if (typeof reader.result !== "string") {
        setMessage("Gambar gagal dibaca. Coba pilih file lain.");
        return;
      }
      const nextAttempt: AttemptState = {
        ...attempt,
        drawingResponses: { ...attempt.drawingResponses, [questionNumber]: reader.result },
        lastSavedAt: new Date().toISOString(),
      };
      setAttempt(nextAttempt);
      persistProgress(nextAttempt);
    };
    reader.readAsDataURL(file);
  };

  const updateEcoAnswer = (itemId: number, score: number) => {
    if (!attempt) return;
    const nextAttempt = {
      ...attempt,
      ecoResponses: { ...attempt.ecoResponses, [itemId]: score },
      lastSavedAt: new Date().toISOString(),
    };
    setAttempt(nextAttempt);
    persistProgress(nextAttempt);
  };

  const updateUsabilityAnswer = (itemId: number, score: number) => {
    if (!attempt) return;
    const nextAttempt = {
      ...attempt,
      usabilityResponses: { ...attempt.usabilityResponses, [itemId]: score },
      lastSavedAt: new Date().toISOString(),
    };
    setAttempt(nextAttempt);
    persistProgress(nextAttempt);
  };

  const updateUsabilityFeedback = (field: "mostHelpful" | "encounteredProblems", value: string) => {
    if (!attempt) return;
    const nextAttempt: AttemptState = {
      ...attempt,
      usabilityOpen: { ...attempt.usabilityOpen, [field]: value },
      lastSavedAt: new Date().toISOString(),
    };
    setAttempt(nextAttempt);
    persistProgress(nextAttempt);
  };

  const goToNextQuestion = () => {
    if (questionIndex === SCIENCE_QUESTIONS.length) {
      if (attempt && persistProgress(attempt)) {
        setView("eco");
      }
      return;
    }

    if (attempt && !persistProgress(attempt)) return;
    const nextQuestionNumber = Math.min(questionIndex + 1, SCIENCE_QUESTIONS.length);
    setQuestionIndex(nextQuestionNumber);
    setView("question");
  };

  const goToPreviousQuestion = () => {
    const previousQuestionNumber = Math.max(questionIndex - 1, 1);
    setQuestionIndex(previousQuestionNumber);
    setView("question");
  };

  const continueToUsability = () => {
    if (attempt && persistProgress(attempt)) {
      setView("usability");
    }
  };

  const continueToReview = () => {
    if (attempt && persistProgress(attempt)) {
      setView("review");
    }
  };

  const handleSubmitFinal = () => {
    if (!attempt) return;

    const emptyQuestions = unansweredScientific.length;
    if (emptyQuestions > 0) {
      setMessage(`Masih ada ${emptyQuestions} soal Scientific Creativity yang belum dijawab. Silakan cek kembali sebelum submit.`);
      setView("review");
      return;
    }

    setIsSubmitting(true);
    const confirmed = window.confirm(
      "Apakah kamu yakin ingin mengirim jawaban? Setelah dikirim, jawaban tidak dapat diubah kecuali peneliti membuka kembali sesi.",
    );

    if (!confirmed) {
      setIsSubmitting(false);
      return;
    }

    const finalAttempt: AttemptState = {
      ...attempt,
      status: "submitted",
      submittedAt: new Date().toISOString(),
      lastSavedAt: new Date().toISOString(),
    };
    if (!persistProgress(finalAttempt)) {
      setIsSubmitting(false);
      return;
    }
    setAttempt(finalAttempt);
    setView("summary");
    setIsSubmitting(false);
    setMessage("");
  };

  const renderIdentity = () => (
    <div className="space-y-6 rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
      <div className="flex items-center justify-between gap-4">
        <div>
          <p className="text-sm font-semibold uppercase tracking-[0.2em] text-blue-700">Identitas siswa</p>
          <h2 className="mt-2 text-2xl font-bold text-slate-900">Isi data peserta</h2>
        </div>
        <span className="rounded-full bg-emerald-100 px-3 py-1 text-xs font-semibold text-emerald-700">{DEMO_MODE_LABEL}</span>
      </div>
      <div className="grid gap-4 md:grid-cols-2">
        <label className="space-y-2 text-sm font-medium text-slate-700">
          Nama atau inisial
          <input
            value={identity.nameOrInitial}
            onChange={(event) => setIdentity((current) => ({ ...current, nameOrInitial: event.target.value }))}
            className="w-full rounded-xl border border-slate-300 px-3 py-2.5 text-base outline-none ring-0 focus:border-blue-600"
            placeholder="Contoh: Aisha"
          />
        </label>
        <label className="space-y-2 text-sm font-medium text-slate-700">
          Kode peserta
          <input
            value={identity.participantCode}
            onChange={(event) => setIdentity((current) => ({ ...current, participantCode: event.target.value }))}
            className="w-full rounded-xl border border-slate-300 px-3 py-2.5 text-base outline-none ring-0 focus:border-blue-600"
            placeholder="Contoh: SCEL-101"
          />
        </label>
        <label className="space-y-2 text-sm font-medium text-slate-700">
          Sekolah
          <input
            value={identity.school}
            onChange={(event) => setIdentity((current) => ({ ...current, school: event.target.value }))}
            className="w-full rounded-xl border border-slate-300 px-3 py-2.5 text-base outline-none ring-0 focus:border-blue-600"
            placeholder="Nama sekolah"
          />
        </label>
        <label className="space-y-2 text-sm font-medium text-slate-700">
          Kelas
          <input
            value={identity.className}
            onChange={(event) => setIdentity((current) => ({ ...current, className: event.target.value }))}
            className="w-full rounded-xl border border-slate-300 px-3 py-2.5 text-base outline-none ring-0 focus:border-blue-600"
            placeholder="Contoh: XI MIPA 1"
          />
        </label>
      </div>
      <label className="flex items-start gap-3 rounded-2xl border border-slate-200 bg-slate-50 p-4 text-sm text-slate-700">
        <input
          type="checkbox"
          checked={identity.consent}
          onChange={(event) => setIdentity((current) => ({ ...current, consent: event.target.checked }))}
          className="mt-1 h-4 w-4 rounded border-slate-300 text-blue-600"
        />
        <span>
          Saya menyetujui mengikuti prosedur asesmen sesuai ketentuan penelitian dan bersedia melanjutkan mengerjakan tugas.
        </span>
      </label>

      {message ? (
        <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">{message}</div>
      ) : null}

      <div className="flex justify-end">
        <button type="button" onClick={handleIdentitySubmit} className="btn-primary">
          Lanjut ke Petunjuk
        </button>
      </div>
    </div>
  );

  const renderInstructions = () => (
    <div className="space-y-6 rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
      <div>
        <p className="text-sm font-semibold uppercase tracking-[0.2em] text-blue-700">Petunjuk pengerjaan</p>
        <h2 className="mt-2 text-2xl font-bold text-slate-900">Panduan sebelum memulai</h2>
      </div>
      <ol className="space-y-4 text-base text-slate-700">
        <li>1. Bacalah stimulus dan pertanyaan dengan cermat.</li>
        <li>2. Gunakan gagasan sendiri untuk menjawab.</li>
        <li>3. Pada soal tertentu, tuliskan beberapa jawaban yang berbeda dan masuk akal secara ilmiah.</li>
        <li>4. Jawaban kreativitas ilmiah berbentuk uraian terbuka.</li>
        <li>5. Pada soal desain produk, siswa dapat menulis penjelasan dan mengunggah gambar rancangan.</li>
        <li>6. Jawablah angket Eco-Religious sesuai pendapat atau keadaan diri sendiri.</li>
        <li>7. Jawablah angket Usability setelah selesai menggunakan website.</li>
        <li>8. Periksa jawaban sebelum dikirim.</li>
        <li>9. Jawaban yang telah dikirim tidak dapat diedit kembali kecuali peneliti membuka kembali sesi sesuai kewenangannya.</li>
      </ol>
      <div className="flex justify-between">
        <Link href="/" className="btn-secondary">Kembali</Link>
        <button type="button" onClick={() => setView("question")} className="btn-primary">
          Mulai soal
        </button>
      </div>
    </div>
  );

  const renderQuestion = () => (
    <div className="space-y-5 rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
      <div className="flex items-center justify-between gap-3">
        <div>
          <p className="text-sm font-semibold uppercase tracking-[0.2em] text-blue-700">Soal {currentQuestion.number}</p>
          <h2 className="mt-2 text-2xl font-bold text-slate-900">{currentQuestion.indicator}</h2>
        </div>
      </div>

      {message ? <div role="alert" className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">{message}</div> : null}
      <div aria-label={`Progres soal ${currentQuestion.number} dari ${SCIENCE_QUESTIONS.length}`} className="h-2 w-full overflow-hidden rounded-full bg-slate-200">
        <div className="h-full rounded-full bg-gradient-to-r from-blue-600 to-emerald-500" style={{ width: `${(currentQuestion.number / SCIENCE_QUESTIONS.length) * 100}%` }} />
      </div>

      <div className="rounded-2xl border border-slate-200 bg-slate-50 p-5">
        <p className="whitespace-pre-line text-base leading-8 text-slate-700">{currentQuestion.prompt}</p>
      </div>

      <label className="block text-sm font-medium text-slate-700">
        Jawaban Anda
        <textarea
          value={attempt?.scientificResponses[currentQuestion.number] ?? ""}
          onChange={(event) => updateScientificAnswer(event.target.value)}
          rows={10}
          className="mt-2 w-full rounded-xl border border-slate-300 px-3 py-2.5 text-base outline-none focus:border-blue-600"
          placeholder="Tulis jawaban Anda di sini..."
        />
      </label>

      {[13, 14].includes(currentQuestion.number) ? (
        <div className="space-y-3 rounded-2xl border border-slate-200 p-4">
          <label className="block text-sm font-medium text-slate-700">
            Unggah gambar rancangan (opsional, maksimal 1 MB)
            <input
              type="file"
              accept="image/png,image/jpeg"
              onChange={(event) => uploadDrawing(currentQuestion.number, event.target.files?.[0])}
              className="mt-2 block w-full text-sm"
            />
          </label>
          {attempt?.drawingResponses?.[currentQuestion.number] ? (
            <Image
              src={attempt.drawingResponses[currentQuestion.number]}
              alt={`Rancangan produk untuk soal ${currentQuestion.number}`}
              width={640}
              height={480}
              unoptimized
              className="max-h-64 max-w-full rounded-lg border border-slate-200 object-contain"
            />
          ) : null}
        </div>
      ) : null}

      <p aria-live="polite" className={`text-sm ${saveStatus === "error" ? "text-red-700" : "text-slate-500"}`}>
        Status penyimpanan: {saveStatus === "saved" ? "Tersimpan di browser" : saveStatus === "saving" ? "Menyimpan..." : saveStatus === "error" ? "Gagal menyimpan" : "Belum ada perubahan"}
      </p>

      <div className="flex justify-between gap-3">
        <button type="button" onClick={goToPreviousQuestion} className="btn-secondary" disabled={questionIndex === 1}>
          Sebelumnya
        </button>
        <button type="button" onClick={goToNextQuestion} className="btn-primary">
          {questionIndex === SCIENCE_QUESTIONS.length ? "Simpan dan lanjut ke Eco" : "Simpan dan lanjut"}
        </button>
      </div>
    </div>
  );

  const renderPhet = () => (
    <div className="space-y-6 rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
      <div>
        <p className="text-sm font-semibold uppercase tracking-[0.2em] text-blue-700">Eksplorasi PhET</p>
        <h2 className="mt-2 text-2xl font-bold text-slate-900">Rangkaian listrik DC</h2>
      </div>
      <div className="rounded-2xl border border-slate-200 bg-slate-50 p-5 text-slate-700">
        <p>Gunakan simulasi resmi PhET untuk mengeksplorasi hukum Ohm, arus, tegangan, hambatan, dan rangkaian seri serta paralel.</p>
      </div>
      <div className="flex flex-wrap gap-3">
        <a href="https://phet.colorado.edu/sims/html/circuit-construction-kit-dc/latest/circuit-construction-kit-dc_en.html" target="_blank" rel="noreferrer" className="btn-primary">
          Buka Simulasi PhET
        </a>
        <button type="button" onClick={() => setView("question")} className="btn-secondary">
          Kembali ke asesmen
        </button>
      </div>
    </div>
  );

  const renderEco = () => (
    <div className="space-y-6 rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
      <div>
        <p className="text-sm font-semibold uppercase tracking-[0.2em] text-blue-700">Angket Eco-Religious</p>
        <h2 className="mt-2 text-2xl font-bold text-slate-900">24 item sikap eco-religious</h2>
      </div>
      {message ? <div role="alert" className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">{message}</div> : null}
      <div className="space-y-5">
        {ECO_ITEMS.map((item) => (
          <div key={item.id} className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
            <div className="mb-3 flex items-center justify-between gap-3">
              <p className="font-semibold text-slate-800">{item.dimension} - Item {item.id}</p>
              <span className="text-xs font-semibold uppercase tracking-wide text-slate-500">{item.number}</span>
            </div>
            <p className="mb-4 text-slate-700">{item.statement}</p>
            <div className="grid grid-cols-5 gap-2 text-center text-xs font-medium text-slate-700">
              {[5, 4, 3, 2, 1].map((score) => (
                <label key={score} className="flex cursor-pointer flex-col items-center gap-2 rounded-xl border border-slate-200 bg-white p-2">
                  <input
                    type="radio"
                    name={`eco-item-${item.id}`}
                    checked={(attempt?.ecoResponses[item.id] ?? null) === score}
                    onChange={() => updateEcoAnswer(item.id, score)}
                    className="h-4 w-4 text-blue-600"
                  />
                  <span>{score}</span>
                </label>
              ))}
            </div>
            <div className="mt-2 flex justify-between text-[10px] uppercase tracking-wide text-slate-500">
              <span>Sangat tidak setuju</span>
              <span>Sangat setuju</span>
            </div>
          </div>
        ))}
      </div>
      <div className="flex justify-between">
        <button type="button" onClick={() => setView("question")} className="btn-secondary">
          Kembali ke soal
        </button>
        <button type="button" onClick={continueToUsability} className="btn-primary">
          Lanjut ke usability
        </button>
      </div>
    </div>
  );

  const renderUsability = () => (
    <div className="space-y-6 rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
      <div>
        <p className="text-sm font-semibold uppercase tracking-[0.2em] text-blue-700">Angket usability</p>
        <h2 className="mt-2 text-2xl font-bold text-slate-900">15 item evaluasi website</h2>
      </div>
      {message ? <div role="alert" className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">{message}</div> : null}
      <div className="space-y-5">
        {USABILITY_ITEMS.map((item) => (
          <div key={item.id} className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
            <div className="mb-3 flex items-center justify-between gap-3">
              <p className="font-semibold text-slate-800">{item.aspect} - Item {item.item_number}</p>
            </div>
            <p className="mb-4 text-slate-700">{item.statement}</p>
            <div className="grid grid-cols-5 gap-2 text-center text-xs font-medium text-slate-700">
              {[5, 4, 3, 2, 1].map((score) => (
                <label key={score} className="flex cursor-pointer flex-col items-center gap-2 rounded-xl border border-slate-200 bg-white p-2">
                  <input
                    type="radio"
                    name={`usability-item-${item.id}`}
                    checked={(attempt?.usabilityResponses[item.id] ?? null) === score}
                    onChange={() => updateUsabilityAnswer(item.id, score)}
                    className="h-4 w-4 text-blue-600"
                  />
                  <span>{score}</span>
                </label>
              ))}
            </div>
          </div>
        ))}
      </div>
      <div className="space-y-3 rounded-2xl border border-slate-200 bg-slate-50 p-4">
        <label className="block text-sm font-medium text-slate-700">
          Apa bagian website yang paling membantu?
          <textarea
            rows={3}
            value={attempt?.usabilityOpen.mostHelpful ?? ""}
            onChange={(event) => updateUsabilityFeedback("mostHelpful", event.target.value)}
            className="mt-2 w-full rounded-xl border border-slate-300 px-3 py-2 text-base outline-none focus:border-blue-600"
          />
        </label>
        <label className="block text-sm font-medium text-slate-700">
          Apa kendala yang kamu alami?
          <textarea
            rows={3}
            value={attempt?.usabilityOpen.encounteredProblems ?? ""}
            onChange={(event) => updateUsabilityFeedback("encounteredProblems", event.target.value)}
            className="mt-2 w-full rounded-xl border border-slate-300 px-3 py-2 text-base outline-none focus:border-blue-600"
          />
        </label>
      </div>
      <div className="flex justify-between">
        <button type="button" onClick={() => setView("eco")} className="btn-secondary">
          Kembali ke Eco
        </button>
        <button type="button" onClick={continueToReview} className="btn-primary">
          Review jawaban
        </button>
      </div>
    </div>
  );

  const renderReview = () => (
    <div className="space-y-6 rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
      <div>
        <p className="text-sm font-semibold uppercase tracking-[0.2em] text-blue-700">Review</p>
        <h2 className="mt-2 text-2xl font-bold text-slate-900">Cek kelengkapan jawaban</h2>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
          <p className="text-sm font-semibold text-slate-600">Scientific Creativity</p>
          <p className="mt-2 text-3xl font-bold text-slate-900">{SCIENCE_QUESTIONS.length - unansweredScientific.length}/{SCIENCE_QUESTIONS.length}</p>
          {unansweredScientific.length > 0 ? <p className="mt-2 text-sm text-orange-600">Belum dijawab: {unansweredScientific.join(", ")}</p> : <p className="mt-2 text-sm text-emerald-600">Semua soal sudah dijawab.</p>}
        </div>
        <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
          <p className="text-sm font-semibold text-slate-600">Eco-Religious</p>
          <p className="mt-2 text-3xl font-bold text-slate-900">{ECO_ITEMS.length - unansweredEco.length}/{ECO_ITEMS.length}</p>
          {unansweredEco.length > 0 ? <p className="mt-2 text-sm text-orange-600">Ada item yang belum diisi.</p> : <p className="mt-2 text-sm text-emerald-600">Semua item sudah diisi.</p>}
        </div>
        <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
          <p className="text-sm font-semibold text-slate-600">Usability</p>
          <p className="mt-2 text-3xl font-bold text-slate-900">{USABILITY_ITEMS.length - unansweredUsability.length}/{USABILITY_ITEMS.length}</p>
          {unansweredUsability.length > 0 ? <p className="mt-2 text-sm text-orange-600">Ada item yang belum diisi.</p> : <p className="mt-2 text-sm text-emerald-600">Semua item sudah diisi.</p>}
        </div>
      </div>

      {message ? <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">{message}</div> : null}

      <div className="flex flex-wrap gap-3">
        <button type="button" onClick={() => setView("question")} className="btn-secondary">Kembali ke soal</button>
        <button type="button" onClick={() => setView("phet")} className="btn-secondary">Eksplorasi PhET</button>
        <button type="button" onClick={() => setView("eco")} className="btn-secondary">Eco-Religious</button>
        <button type="button" onClick={() => setView("usability")} className="btn-secondary">Usability</button>
        <button type="button" onClick={handleSubmitFinal} className="btn-primary" disabled={isSubmitting}>
          {isSubmitting ? "Mengirim..." : "Submit final"}
        </button>
      </div>
    </div>
  );

  const renderSummary = () => (
    <div className="space-y-6 rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
      <div className="text-center">
        <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-emerald-100 text-2xl">✓</div>
        <p className="text-sm font-semibold uppercase tracking-[0.2em] text-emerald-700">Submit berhasil</p>
        <h2 className="mt-2 text-3xl font-bold text-slate-900">Jawaban berhasil dikirim.</h2>
        <p className="mt-3 text-lg text-slate-700">Terima kasih telah mengikuti Digital Assessment SCEL.</p>
      </div>
      <div className="rounded-2xl border border-emerald-200 bg-emerald-50 p-4 text-sm text-emerald-700">
        Data jawaban Anda telah disimpan dan tidak dapat diubah ulang sebelum peneliti membuka kembali sesi.
      </div>
      <div className="flex justify-center">
        <Link href="/" className="btn-primary">Kembali ke beranda</Link>
      </div>
    </div>
  );

  const renderMain = () => {
    if (view === "identity") return renderIdentity();
    if (view === "instructions") return renderInstructions();
    if (view === "question") return renderQuestion();
    if (view === "phet") return renderPhet();
    if (view === "eco") return renderEco();
    if (view === "usability") return renderUsability();
    if (view === "review") return renderReview();
    if (view === "summary") return renderSummary();
    return renderIdentity();
  };

  return (
    <main className="mx-auto w-full max-w-5xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="mb-8 flex flex-col gap-3 rounded-3xl bg-gradient-to-r from-blue-900 via-blue-700 to-emerald-600 p-6 text-white shadow-xl">
        <div className="flex items-center justify-between gap-3">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.3em] text-blue-100">Digital Assessment SCEL</p>
            <h1 className="mt-2 text-3xl font-bold">Asesmen Fisika Digital</h1>
          </div>
          <span className="rounded-full border border-white/25 bg-white/10 px-3 py-1 text-xs font-semibold uppercase tracking-wide text-blue-50">{DEMO_MODE_LABEL}</span>
        </div>
        <p className="max-w-3xl text-sm text-blue-50/90">
          Platform asesmen digital untuk mengeksplorasi kreativitas ilmiah melalui Arus Listrik Searah dan memahami sikap eco-religious siswa.
        </p>
      </div>
      {renderMain()}
    </main>
  );
}
