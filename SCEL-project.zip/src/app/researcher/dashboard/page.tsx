import ResearcherDashboard from "@/components/researcher-dashboard";

export default function ResearcherDashboardPage() {
  return <ResearcherDashboard initialTab="dashboard" />;
}
