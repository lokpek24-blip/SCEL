import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Digital Assessment SCEL",
  description: "Digital Assessment SCEL for scientific creativity and eco-religious learning.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="id" className="h-full antialiased">
      <body className="min-h-full bg-slate-100 text-slate-900">{children}</body>
    </html>
  );
}
