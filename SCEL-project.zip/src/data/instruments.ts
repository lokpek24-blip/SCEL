export type ScienceQuestion = {
  id: number;
  number: number;
  indicator: string;
  prompt: string;
};

export const SCIENCE_QUESTIONS: ScienceQuestion[] = [
  {
    id: 1,
    number: 1,
    indicator: "Unusual Uses",
    prompt:
      "Perhatikan benda atau material sederhana yang sering kamu temukan di rumah atau lingkungan sekitar.\n\nDari benda atau material tersebut, pilih salah satu yang menurutmu dapat dimanfaatkan dalam suatu kegiatan ilmiah atau edukasi yang berkaitan dengan energi listrik atau rangkaian listrik DC. Sebutkan sebanyak mungkin kegunaan alternatif yang dapat kamu pikirkan. Jelaskan secara singkat bagaimana benda tersebut dapat digunakan dan manfaatnya!",
  },
  {
    id: 2,
    number: 2,
    indicator: "Unusual Uses",
    prompt:
      "Di lingkungan sekitar kita terdapat berbagai komponen listrik yang sudah tidak digunakan, tetapi mungkin masih dapat dimanfaatkan untuk kegiatan lain.\n\nPilih salah satu komponen pada ilustrasi tersebut. Sebutkan sebanyak mungkin ide pemanfaatan lain dari komponen tersebut dalam suatu alat atau kegiatan sederhana yang berkaitan dengan listrik DC. Jelaskan fungsi komponen tersebut pada setiap ide yang kamu berikan!",
  },
  {
    id: 3,
    number: 3,
    indicator: "Problem Finding",
    prompt:
      "Perhatikan fenomena pada ilustrasi tersebut. Meskipun menggunakan sumber tegangan dan lampu yang sama, cahaya lampu dapat terlihat berbeda ketika panjang kabel yang digunakan berbeda.\n\nBerdasarkan fenomena tersebut, rumuskan sebanyak mungkin pertanyaan atau masalah ilmiah yang menurutmu menarik untuk diteliti. Pilih salah satu pertanyaan yang menurutmu paling menarik dan jelaskan alasanmu!",
  },
  {
    id: 4,
    number: 4,
    indicator: "Problem Finding",
    prompt:
      "Sebuah motor listrik DC dapat mengalami perubahan kecepatan ketika kondisi bebannya berubah.\n\nMenurut pemikiranmu, masalah atau pertanyaan ilmiah apa saja yang dapat muncul dari fenomena tersebut? Tuliskan sebanyak mungkin pertanyaan yang berbeda dan dapat diselidiki melalui percobaan sederhana!",
  },
  {
    id: 5,
    number: 5,
    indicator: "Scientific Imagination",
    prompt:
      "Bayangkan suatu saat manusia berhasil membuat kabel listrik yang memiliki hambatan hampir nol.\n\nMenurut imajinasimu, apa yang mungkin terjadi ketika kabel tersebut digunakan pada rangkaian listrik DC? Tuliskan beberapa kemungkinan perubahan yang dapat terjadi pada arus, tegangan, daya, panas, atau penggunaan energi. Jelaskan alasan ilmiah dari jawabanmu!",
  },
  {
    id: 6,
    number: 6,
    indicator: "Scientific Imagination",
    prompt:
      "Bayangkan pada masa depan tersedia sebuah sumber listrik DC pintar yang dapat menyesuaikan tegangan secara otomatis sesuai dengan kebutuhan setiap perangkat.\n\nMenurut imajinasimu, alat atau teknologi apa saja yang dapat dikembangkan menggunakan sistem tersebut? Sebutkan sebanyak mungkin kemungkinan yang dapat kamu pikirkan dan jelaskan manfaatnya!",
  },
  {
    id: 7,
    number: 7,
    indicator: "Product Improvement",
    prompt:
      "Senter merupakan salah satu alat listrik sederhana yang banyak digunakan ketika membutuhkan penerangan. Namun, baterai pada senter dapat cepat habis dan menghasilkan limbah setelah tidak digunakan.\n\nBayangkan kamu diminta memperbaiki senter tersebut. Sebutkan sebanyak mungkin perubahan atau fitur yang dapat ditambahkan agar senter menjadi lebih hemat energi, lebih praktis, dan dapat digunakan lebih lama. Jelaskan manfaat dari setiap perubahan yang kamu usulkan!",
  },
  {
    id: 8,
    number: 8,
    indicator: "Product Improvement",
    prompt:
      "Sebuah lampu belajar portabel dapat digunakan di berbagai tempat. Akan tetapi, ketika tingkat kecerahan lampu terlalu tinggi, baterainya menjadi lebih cepat habis.\n\nMenurutmu, bagaimana cara memperbaiki produk tersebut agar tetap memberikan penerangan yang baik tetapi penggunaan energinya lebih efisien? Tuliskan beberapa ide perbaikan dan jelaskan prinsip listrik yang mendukung ide tersebut!",
  },
  {
    id: 9,
    number: 9,
    indicator: "Creatively Science Problem Solving",
    prompt:
      "Sebuah pos penjagaan di daerah terpencil menggunakan panel surya sebagai sumber energi listrik. Ketika cuaca mendung, energi listrik yang tersedia menjadi lebih sedikit, sedangkan lampu tetap harus digunakan.\n\nMenurutmu, solusi apa saja yang dapat dilakukan agar kebutuhan penerangan tetap terpenuhi meskipun energi listrik yang tersedia terbatas? Tuliskan beberapa solusi yang berbeda dan jelaskan alasan ilmiah dari setiap solusi!",
  },
  {
    id: 10,
    number: 10,
    indicator: "Creatively Science Problem Solving",
    prompt:
      "Sebuah pompa air DC digunakan untuk mengalirkan air menggunakan sumber energi dari baterai. Dalam penggunaannya, baterai sering habis sebelum kebutuhan air selesai.\n\nBayangkan kamu diminta menyelesaikan masalah tersebut. Kemukakan beberapa alternatif solusi yang dapat dilakukan agar pompa tetap dapat digunakan dengan energi baterai yang terbatas. Jelaskan kelebihan dari solusi yang kamu usulkan!",
  },
  {
    id: 11,
    number: 11,
    indicator: "Creative Experimental Design",
    prompt:
      "Kamu ingin mengetahui apakah panjang kabel dapat memengaruhi arus listrik yang mengalir dalam suatu rangkaian.\n\nRancanglah sebuah percobaan sederhana untuk mengetahui pengaruh panjang kabel tersebut. Jelaskan alat yang digunakan, perubahan yang dilakukan, pengukuran yang dilakukan, dan langkah utama percobaannya!",
  },
  {
    id: 12,
    number: 12,
    indicator: "Creative Experimental Design",
    prompt:
      "Beberapa jenis buah dapat digunakan sebagai sumber listrik DC sederhana. Namun, besar arus yang dihasilkan setiap buah belum tentu sama.\n\nJika kamu diminta menyelidiki buah mana yang dapat menghasilkan arus listrik paling besar, bagaimana rancangan percobaan yang akan kamu lakukan? Jelaskan apa yang akan kamu ubah, apa yang akan kamu ukur, dan bagaimana cara membandingkan hasilnya!",
  },
  {
    id: 13,
    number: 13,
    indicator: "Creative Product Design",
    prompt:
      "Ketika terjadi bencana, jaringan listrik dapat terputus sehingga masyarakat kesulitan mengisi daya perangkat komunikasi.\n\nBayangkan kamu diminta membuat sebuah charger portabel berbasis listrik DC yang dapat digunakan dalam kondisi tersebut. Gambarkan desain sederhana produkmu dan jelaskan komponen utama, fungsi setiap komponen, serta cara kerja produk tersebut!",
  },
  {
    id: 14,
    number: 14,
    indicator: "Creative Product Design",
    prompt:
      "Pemadaman listrik dapat menyebabkan aktivitas masyarakat terganggu, terutama ketika tidak tersedia sumber penerangan alternatif.\n\nRancang sebuah lampu darurat berbasis listrik DC yang menurutmu lebih hemat energi dan praktis dibandingkan lampu darurat biasa. Gambarkan desainnya dan jelaskan komponen utama, prinsip kerja, serta keunggulan produk yang kamu buat!",
  },
];

export const ECO_ITEMS = [
  { id: 1, number: 1, dimension: "Respect for Nature", statement: "Saya menghargai penggunaan energi listrik secara bijaksana karena alam perlu dijaga." },
  { id: 2, number: 2, dimension: "Respect for Nature", statement: "Saya memperhatikan dampak penggunaan listrik terhadap lingkungan." },
  { id: 3, number: 3, dimension: "Respect for Nature", statement: "Saya menganggap menjaga keseimbangan lingkungan merupakan hal yang penting." },
  { id: 4, number: 4, dimension: "Respect for Nature", statement: "Saya menghindari penggunaan listrik secara berlebihan ketika tidak diperlukan." },
  { id: 5, number: 5, dimension: "Respect for Nature", statement: "Saya merasa perlu menjaga lingkungan tempat saya belajar agar tetap nyaman bagi makhluk hidup." },
  { id: 6, number: 6, dimension: "Respect for Nature", statement: "Saya mempertimbangkan kelestarian lingkungan ketika menggunakan teknologi listrik." },
  { id: 7, number: 1, dimension: "Moral Responsibility for Nature", statement: "Saya merasa bertanggung jawab untuk menghemat listrik dalam kehidupan sehari-hari." },
  { id: 8, number: 2, dimension: "Moral Responsibility for Nature", statement: "Saya berusaha mematikan peralatan listrik yang tidak sedang digunakan." },
  { id: 9, number: 3, dimension: "Moral Responsibility for Nature", statement: "Saya merasa bertanggung jawab terhadap limbah baterai atau komponen listrik yang saya gunakan." },
  { id: 10, number: 4, dimension: "Moral Responsibility for Nature", statement: "Saya bersedia mengubah kebiasaan penggunaan listrik yang boros." },
  { id: 11, number: 5, dimension: "Moral Responsibility for Nature", statement: "Saya tetap berusaha menggunakan energi secara hemat meskipun tidak ada yang mengawasi." },
  { id: 12, number: 6, dimension: "Moral Responsibility for Nature", statement: "Saya memandang menjaga lingkungan sebagai bagian dari tanggung jawab manusia sebagai pengelola bumi." },
  { id: 13, number: 1, dimension: "Cosmic Solidarity", statement: "Saya menyadari bahwa penggunaan energi oleh manusia dapat memengaruhi lingkungan." },
  { id: 14, number: 2, dimension: "Cosmic Solidarity", statement: "Saya memahami bahwa perubahan pada lingkungan dapat berdampak pada kehidupan makhluk lain." },
  { id: 15, number: 3, dimension: "Cosmic Solidarity", statement: "Saya mempertimbangkan dampak penggunaan energi terhadap orang lain dan lingkungan." },
  { id: 16, number: 4, dimension: "Cosmic Solidarity", statement: "Saya menyadari bahwa kebiasaan hemat energi di lingkungan sekolah dapat memberi manfaat lebih luas." },
  { id: 17, number: 5, dimension: "Cosmic Solidarity", statement: "Saya peduli ketika penggunaan energi manusia menimbulkan dampak buruk bagi makhluk hidup." },
  { id: 18, number: 6, dimension: "Cosmic Solidarity", statement: "Saya melihat manusia sebagai bagian dari sistem alam, bukan sebagai pihak yang dapat menggunakan alam tanpa batas." },
  { id: 19, number: 1, dimension: "Caring for Nature", statement: "Saya berusaha menjaga penggunaan listrik di sekolah agar tidak berlebihan." },
  { id: 20, number: 2, dimension: "Caring for Nature", statement: "Saya memilih menggunakan listrik seperlunya." },
  { id: 21, number: 3, dimension: "Caring for Nature", statement: "Saya berusaha mengurangi penggunaan atau pembuangan baterai secara tidak bertanggung jawab." },
  { id: 22, number: 4, dimension: "Caring for Nature", statement: "Saya bersedia ikut melakukan kegiatan yang bertujuan menghemat energi atau mengurangi limbah listrik." },
  { id: 23, number: 5, dimension: "Caring for Nature", statement: "Saya mendukung penggunaan teknologi listrik yang lebih hemat dan ramah lingkungan." },
  { id: 24, number: 6, dimension: "Caring for Nature", statement: "Saya berusaha mempertahankan kebiasaan yang membantu menjaga lingkungan dalam jangka panjang." },
];

export const USABILITY_ITEMS = [
  { id: 1, item_number: 1, aspect: "Kemudahan", statement: "Saya dapat memahami cara menggunakan website asesmen." },
  { id: 2, item_number: 2, aspect: "Navigasi", statement: "Saya mudah menemukan bagian yang ingin saya buka." },
  { id: 3, item_number: 3, aspect: "Navigasi", statement: "Urutan pengerjaan asesmen mudah diikuti." },
  { id: 4, item_number: 4, aspect: "Tampilan", statement: "Tampilan website mudah dipahami." },
  { id: 5, item_number: 5, aspect: "Keterbacaan", statement: "Tulisan dan instruksi dapat saya baca dengan nyaman." },
  { id: 6, item_number: 6, aspect: "Input", statement: "Saya dapat mengetik jawaban dengan mudah." },
  { id: 7, item_number: 7, aspect: "Upload", statement: "Saya dapat mengunggah gambar rancangan dengan mudah." },
  { id: 8, item_number: 8, aspect: "Feedback", statement: "Saya dapat memahami umpan balik yang ditampilkan setelah mengirim jawaban." },
  { id: 9, item_number: 9, aspect: "Respons sistem", statement: "Website merespons ketika saya menekan tombol atau berpindah halaman." },
  { id: 10, item_number: 10, aspect: "Kenyamanan", statement: "Saya nyaman mengerjakan asesmen menggunakan smartphone." },
  { id: 11, item_number: 11, aspect: "Efisiensi", statement: "Penggunaan website membantu saya mengerjakan asesmen secara lebih praktis." },
  { id: 12, item_number: 12, aspect: "Kejelasan", statement: "Instruksi pada setiap bagian cukup jelas tanpa harus banyak bertanya kepada orang lain." },
  { id: 13, item_number: 13, aspect: "Konsistensi", statement: "Tampilan dan tombol pada website terasa konsisten." },
  { id: 14, item_number: 14, aspect: "Kesesuaian", statement: "Fitur yang tersedia mendukung kebutuhan saya saat mengerjakan asesmen." },
  { id: 15, item_number: 15, aspect: "Keseluruhan", statement: "Secara keseluruhan, website Digital Assessment mudah digunakan." },
];

export const QUESTION_DIMENSIONS: Record<number, string[]> = {
  1: ["fluency", "flexibility"],
  2: ["fluency", "flexibility"],
  3: ["fluency", "flexibility"],
  4: ["fluency", "flexibility"],
  5: ["fluency", "flexibility"],
  6: ["fluency", "flexibility"],
  7: ["fluency", "flexibility"],
  8: ["fluency", "flexibility"],
  9: ["fluency", "flexibility", "originality"],
  10: ["fluency", "flexibility", "originality"],
  11: ["flexibility", "originality"],
  12: ["flexibility", "originality"],
  13: ["flexibility", "originality"],
  14: ["flexibility", "originality"],
};

export const RESEARCHER_USERS = [
  { username: "admin", password: "admin123", role: "admin" },
  { username: "rater", password: "rater123", role: "rater" },
  { username: "researcher", password: "research123", role: "researcher" },
];

export const DEMO_MODE_LABEL = "DEMO MODE";
