import StudentAssessment from "@/components/student-assessment";

export default function StudentPage() {
  return <StudentAssessment initialView="identity" />;
}
