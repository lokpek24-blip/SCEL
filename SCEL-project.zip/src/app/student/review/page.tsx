import StudentAssessment from "@/components/student-assessment";

export default function StudentReviewPage() {
  return <StudentAssessment initialView="review" />;
}
