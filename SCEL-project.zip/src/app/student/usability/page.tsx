import StudentAssessment from "@/components/student-assessment";

export default function StudentUsabilityPage() {
  return <StudentAssessment initialView="usability" />;
}
