import StudentAssessment from "@/components/student-assessment";

export default function StudentInstructionsPage() {
  return <StudentAssessment initialView="instructions" />;
}
