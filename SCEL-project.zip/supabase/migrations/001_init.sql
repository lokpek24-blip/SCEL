CREATE TABLE IF NOT EXISTS participants (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  participant_code TEXT NOT NULL UNIQUE,
  name_or_initial TEXT,
  school TEXT,
  class_name TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS assessment_attempts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  participant_id UUID REFERENCES participants(id) ON DELETE CASCADE,
  instrument_version TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'in_progress',
  started_at TIMESTAMPTZ DEFAULT NOW(),
  submitted_at TIMESTAMPTZ,
  last_saved_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS scientific_creativity_questions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  question_number INTEGER NOT NULL,
  indicator TEXT,
  question_text TEXT NOT NULL,
  illustration_path TEXT,
  scoring_dimensions TEXT[] NOT NULL,
  instrument_version TEXT NOT NULL,
  active BOOLEAN DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS scientific_creativity_responses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  attempt_id UUID REFERENCES assessment_attempts(id) ON DELETE CASCADE,
  question_id UUID REFERENCES scientific_creativity_questions(id) ON DELETE CASCADE,
  text_response TEXT,
  uploaded_image_path TEXT,
  drawing_image_path TEXT,
  saved_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS eco_religious_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  item_number INTEGER NOT NULL,
  dimension TEXT NOT NULL,
  statement TEXT NOT NULL,
  instrument_version TEXT NOT NULL,
  active BOOLEAN DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS eco_religious_responses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  attempt_id UUID REFERENCES assessment_attempts(id) ON DELETE CASCADE,
  item_id UUID REFERENCES eco_religious_items(id) ON DELETE CASCADE,
  score INTEGER,
  saved_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS usability_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  item_number INTEGER NOT NULL,
  aspect TEXT,
  statement TEXT NOT NULL,
  instrument_version TEXT NOT NULL,
  active BOOLEAN DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS usability_responses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  attempt_id UUID REFERENCES assessment_attempts(id) ON DELETE CASCADE,
  item_id UUID REFERENCES usability_items(id) ON DELETE CASCADE,
  score INTEGER,
  saved_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS usability_comments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  attempt_id UUID REFERENCES assessment_attempts(id) ON DELETE CASCADE,
  most_helpful TEXT,
  encountered_problems TEXT,
  saved_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS rater_scores (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  attempt_id UUID REFERENCES assessment_attempts(id) ON DELETE CASCADE,
  question_id UUID REFERENCES scientific_creativity_questions(id) ON DELETE CASCADE,
  rater_id TEXT NOT NULL,
  fluency_score INTEGER,
  flexibility_score INTEGER,
  originality_score INTEGER,
  notes TEXT,
  scored_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS validators (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  validator_code TEXT NOT NULL UNIQUE,
  validator_domain TEXT NOT NULL,
  display_name TEXT,
  active BOOLEAN DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS validation_criteria (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  domain TEXT,
  criterion_code TEXT,
  criterion_text TEXT,
  related_question_id UUID REFERENCES scientific_creativity_questions(id),
  instrument_version TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS validation_scores (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  validator_id UUID REFERENCES validators(id) ON DELETE CASCADE,
  criterion_id UUID REFERENCES validation_criteria(id) ON DELETE CASCADE,
  score INTEGER,
  comments TEXT,
  scored_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS teacher_interviews (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  school TEXT,
  teacher_initial TEXT,
  interview_date DATE,
  interviewer TEXT,
  responses_json JSONB,
  field_notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS needs_observations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  school TEXT,
  observer TEXT,
  observation_date DATE,
  class_name TEXT,
  material TEXT,
  observations_json JSONB,
  discussion_notes TEXT,
  conclusion TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS participants_code_idx ON participants(participant_code);
CREATE INDEX IF NOT EXISTS attempts_status_idx ON assessment_attempts(status);
CREATE INDEX IF NOT EXISTS rater_scores_attempt_idx ON rater_scores(attempt_id);
CREATE INDEX IF NOT EXISTS eco_responses_attempt_idx ON eco_religious_responses(attempt_id);
CREATE INDEX IF NOT EXISTS usability_responses_attempt_idx ON usability_responses(attempt_id);
