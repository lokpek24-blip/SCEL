import { ECO_ITEMS, QUESTION_DIMENSIONS } from "@/data/instruments";
import type { AttemptState, DemoStore, Participant } from "@/lib/demo-store";

export function isDemoParticipant(participant: Participant) {
  return participant.id.startsWith("demo-participant-");
}

export function isDemoAttempt(attempt: AttemptState) {
  return attempt.id.startsWith("demo-attempt-") || attempt.participantId.startsWith("demo-participant-");
}

export function getResearchStore(store: DemoStore): DemoStore {
  const attempts = store.attempts.filter((attempt) => !isDemoAttempt(attempt));
  const attemptIds = new Set(attempts.map((attempt) => attempt.id));
  const participants = store.participants.filter((participant) => !isDemoParticipant(participant));

  return {
    participants,
    attempts,
    teacherInterviews: store.teacherInterviews.filter((item) => !item.id.startsWith("demo-")),
    needsObservations: store.needsObservations.filter((item) => !item.id.startsWith("demo-")),
    raterScores: store.raterScores.filter((score) => !score.id.startsWith("demo-") && attemptIds.has(score.attemptId)),
    validationScores: store.validationScores.filter((score) => !score.id.startsWith("demo-")),
  };
}

export function getLatestAttempt(attempts: AttemptState[], participantId: string) {
  return attempts
    .filter((attempt) => attempt.participantId === participantId)
    .sort((a, b) => b.lastSavedAt.localeCompare(a.lastSavedAt))[0];
}

function validEcoResponse(attempt: AttemptState, itemId: number) {
  const score = attempt.ecoResponses[itemId];
  return Number.isInteger(score) && score >= 1 && score <= 5 ? score : undefined;
}

export function getEcoSummary(attempts: AttemptState[]) {
  const submitted = attempts.filter((attempt) => attempt.status === "submitted");
  const values = submitted.flatMap((attempt) =>
    ECO_ITEMS.map((item) => validEcoResponse(attempt, item.id)).filter((score): score is number => score !== undefined),
  );
  const mean = values.length ? values.reduce((sum, score) => sum + score, 0) / values.length : null;
  const completeAttempts = submitted.filter((attempt) =>
    ECO_ITEMS.every((item) => validEcoResponse(attempt, item.id) !== undefined),
  );

  if (completeAttempts.length < 2) {
    return { mean, alpha: null, validResponses: values.length, completeParticipants: completeAttempts.length };
  }

  const itemVariances = ECO_ITEMS.map((item) => sampleVariance(
    completeAttempts.map((attempt) => validEcoResponse(attempt, item.id)!),
  ));
  const totalScores = completeAttempts.map((attempt) =>
    ECO_ITEMS.reduce((sum, item) => sum + validEcoResponse(attempt, item.id)!, 0),
  );
  const totalVariance = sampleVariance(totalScores);
  const alpha = totalVariance > 0
    ? (ECO_ITEMS.length / (ECO_ITEMS.length - 1)) * (1 - itemVariances.reduce((sum, value) => sum + value, 0) / totalVariance)
    : null;

  return {
    mean,
    alpha: alpha !== null && Number.isFinite(alpha) ? alpha : null,
    validResponses: values.length,
    completeParticipants: completeAttempts.length,
  };
}

function sampleVariance(values: number[]) {
  if (values.length < 2) return 0;
  const mean = values.reduce((sum, value) => sum + value, 0) / values.length;
  return values.reduce((sum, value) => sum + (value - mean) ** 2, 0) / (values.length - 1);
}

export type RaterDimension = "fluency" | "flexibility" | "originality";

export function getRaterScoreMap(store: DemoStore) {
  const map = new Map<string, { r1?: number; r2?: number }>();
  for (const score of store.raterScores) {
    for (const dimension of QUESTION_DIMENSIONS[score.questionId] ?? []) {
      const key = `${score.attemptId}|${score.questionId}|${dimension}`;
      const pair = map.get(key) ?? {};
      const value = score[`${dimension}Score` as "fluencyScore" | "flexibilityScore" | "originalityScore"];
      if (Number.isInteger(value) && value! >= 1 && value! <= 4) {
        if (score.raterId === "rater1") pair.r1 = value;
        if (score.raterId === "rater2") pair.r2 = value;
      }
      map.set(key, pair);
    }
  }
  return map;
}

export function getIrrSummary(store: DemoStore) {
  const scores = getRaterScoreMap(store);
  const pairs = [...scores.values()].filter((pair) => pair.r1 !== undefined && pair.r2 !== undefined);
  const matched = pairs.filter((pair) => pair.r1 === pair.r2).length;
  return {
    total: pairs.length,
    matched,
    agreement: pairs.length ? (matched / pairs.length) * 100 : null,
  };
}

export function getPendingRatingCount(store: DemoStore) {
  const scores = getRaterScoreMap(store);
  return store.attempts
    .filter((attempt) => attempt.status === "submitted")
    .reduce((pending, attempt) => {
      let outstanding = 0;
      Object.entries(QUESTION_DIMENSIONS).forEach(([question, dimensions]) => {
        dimensions.forEach((dimension) => {
          const pair = scores.get(`${attempt.id}|${question}|${dimension}`);
          if (pair?.r1 === undefined) outstanding += 1;
          if (pair?.r2 === undefined) outstanding += 1;
        });
      });
      return pending + outstanding;
    }, 0);
}
