import Link from "next/link";

export default function HomePage() {
  return (
    <main className="mx-auto max-w-6xl px-4 py-10 sm:px-6 lg:px-8">
      <section className="rounded-[2rem] bg-gradient-to-br from-blue-950 via-blue-800 to-emerald-700 p-8 text-white shadow-xl">
        <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
          <div className="max-w-2xl">
            <p className="text-xs font-semibold uppercase tracking-[0.3em] text-blue-100">Digital Assessment SCEL</p>
            <h1 className="mt-3 text-4xl font-bold tracking-tight sm:text-5xl">Asesmen Fisika Digital</h1>
            <p className="mt-4 text-lg text-blue-50/90">
              Platform asesmen digital untuk mengeksplorasi kreativitas ilmiah melalui permasalahan Arus Listrik Searah serta memahami sikap terhadap penggunaan energi dan kepedulian lingkungan.
            </p>
          </div>
          <div className="flex flex-col gap-3 sm:flex-row">
            <Link href="/student/identity" className="btn-primary bg-white text-blue-900 hover:bg-slate-100">
              Mulai Asesmen
            </Link>
            <Link href="/researcher/login" className="btn-secondary border-white/30 bg-white/5 text-white hover:bg-white/10">
              Login Peneliti
            </Link>
          </div>
        </div>
      </section>

      <section className="mt-8 grid gap-5 md:grid-cols-2 xl:grid-cols-4">
        <InfoCard title="Materi" value="Arus Listrik Searah" />
        <InfoCard title="Sasaran" value="Siswa SMA Fase F" />
        <InfoCard title="Bagian asesmen" value="Scientific Creativity, Eco-Religious, Usability" />
        <InfoCard title="Perkiraan waktu" value="30–45 menit" />
      </section>

      <section className="mt-8 grid gap-6 lg:grid-cols-[1.2fr_0.8fr]">
        <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
          <p className="text-sm font-semibold uppercase tracking-[0.2em] text-blue-700">Petunjuk singkat</p>
          <ul className="mt-4 space-y-3 text-slate-700">
            <li>• Isi identitas peserta dengan benar.</li>
            <li>• Kerjakan 14 soal Scientific Creativity secara terbuka.</li>
            <li>• Ikuti angket Eco-Religious dan Usability setelah bagian utama.</li>
            <li>• Gunakan fitur PhET sebagai eksplorasi pendukung.</li>
            <li>• Pastikan semua jawaban Anda tersimpan sebelum submit final.</li>
          </ul>
        </div>
        <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
          <p className="text-sm font-semibold uppercase tracking-[0.2em] text-blue-700">Status aplikasi</p>
          <div className="mt-4 rounded-2xl bg-emerald-50 border border-emerald-200 p-4 text-sm text-emerald-700">
            Mode demonstrasi aktif. Data yang ditampilkan adalah penyimpanan lokal dan tidak menggantikan database produksi yang terkonfigurasi.
          </div>
        </div>
      </section>
    </main>
  );
}

function InfoCard({ title, value }: { title: string; value: string }) {
  return (
    <div className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
      <p className="text-sm font-semibold uppercase tracking-[0.2em] text-slate-500">{title}</p>
      <p className="mt-3 text-lg font-semibold text-slate-900">{value}</p>
    </div>
  );
}
