# Digital Assessment SCEL

Prototype asesmen Scientific Creativity, Eco-Religious, dan Usability dengan Next.js. Data pada konfigurasi saat ini disimpan di `localStorage` browser; aplikasi belum terhubung ke Supabase maupun Google Sheets dan bukan penyimpanan produksi untuk data penelitian.

## Menjalankan secara lokal

```bash
npm install
npm run dev
```

Buka `http://localhost:3000` (atau port yang ditampilkan Next.js). Untuk validasi:

```bash
npm run lint
npm run typecheck
npm test
npm run build
```

## Mode demo dan data

- Peserta, respons, dan skor rater disimpan hanya pada browser/perangkat yang digunakan.
- Data contoh bawaan ditandai dengan ID demo dan tidak disertakan pada statistik atau ekspor penelitian.
- Hindari memasukkan data pribadi/penelitian nyata ke demo, serta hindari menghapus data browser sebelum mengekspor salinan cadangan.
- Kredensial login yang ditampilkan aplikasi hanya akun demo; login browser-side ini bukan kontrol akses produksi.
- Sinkronisasi Google Sheets belum dikonfigurasi. Jangan menaruh kredensial Google di variabel publik atau source frontend.
- Migrasi SQL di `supabase/migrations/` adalah template skema dan tidak berarti proyek sudah tersambung ke Supabase.

## Ekspor workbook

Dashboard admin menyediakan:

- Workbook Excel lengkap berisi sheet terpisah untuk peserta, respons, skor Rater 1/Rater 2, IRR, Eco-Religious, Usability, validasi, wawancara, observasi, serta lima sheet `SPSS_*_Wide`.
- Baris header dibekukan, filter diaktifkan, lebar kolom disesuaikan, kode peserta ditulis sebagai teks, dan jawaban siswa tidak diringkas.
- Gambar rancangan dari soal 13/14 disimpan di browser dan ditanam pada kolom `file_gambar` di workbook Excel.
- CSV UTF-8 dapat diunduh per sheet. Prefiks yang berpotensi menjadi formula spreadsheet di-escape pada file CSV, tanpa mengubah nilai dalam penyimpanan browser.
- Item Eco/Usability yang kosong tetap kosong. Rerata ekspor menghitung nilai valid yang tersedia saja; Cronbach's Alpha hanya dihitung dari sedikitnya dua peserta dengan 24 item valid lengkap.

Wawancara, observasi, dan validasi ahli pada model demo memiliki batasan: misalnya aspek penilaian validator dan jenis instrumen yang tidak disimpan terpisah akan diekspor sebagai kolom kosong, bukan ditebak. Sinkronisasi server dan kredensial integrasi memerlukan konfigurasi backend yang aman sebelum penggunaan produksi.

## Struktur utama

- `src/data/instruments.ts`: redaksi dan urutan instrumen.
- `src/components/student-assessment.tsx`: alur asesmen siswa dan autosave browser.
- `src/components/researcher-dashboard.tsx`: dashboard peneliti, navigasi, penskoran, dan ekspor.
- `src/lib/demo-store.ts`: tipe dan penyimpanan demo localStorage.
- `src/lib/research-analytics.ts`: statistik terhitung dari data penelitian non-demo.
- `src/lib/research-export.ts`: transformasi dataset, CSV, serta workbook Excel.
- `supabase/migrations/001_init.sql`: template skema database.
