import fs from 'node:fs';
import path from 'node:path';

const instrumentVersion = 'SCEL-DC-v1.0-14Q';
const payload = {
  version: instrumentVersion,
  scientificCreativity: 14,
  ecoReligious: 24,
  usability: 15,
  createdAt: new Date().toISOString(),
};

const outputPath = path.join(process.cwd(), 'public', 'instrument-seed.json');
fs.mkdirSync(path.dirname(outputPath), { recursive: true });
fs.writeFileSync(outputPath, JSON.stringify(payload, null, 2));
console.log(`Seeded instrument version ${instrumentVersion} at ${outputPath}`);
