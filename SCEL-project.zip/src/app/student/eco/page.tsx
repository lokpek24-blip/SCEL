import StudentAssessment from "@/components/student-assessment";

export default function StudentEcoPage() {
  return <StudentAssessment initialView="eco" />;
}
