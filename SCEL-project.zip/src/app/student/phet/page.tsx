import StudentAssessment from "@/components/student-assessment";

export default function StudentPhetPage() {
  return <StudentAssessment initialView="phet" />;
}
