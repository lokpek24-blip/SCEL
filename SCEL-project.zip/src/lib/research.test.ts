import assert from "node:assert/strict";
import { test } from "node:test";
import ExcelJS from "exceljs";
import { SCIENCE_QUESTIONS } from "@/data/instruments";
import { emptyDemoStore, type AttemptState, type Participant } from "@/lib/demo-store";
import { getEcoSummary, getIrrSummary, getResearchStore } from "@/lib/research-analytics";
import { createCsvContent, createResearchDatasets, createResearchWorkbook } from "@/lib/research-export";

const makeParticipant = (id: string, code: string): Participant => ({
  id,
  participantCode: code,
  nameOrInitial: code,
  school: "Sekolah uji",
  className: "XI",
  consent: true,
  createdAt: "2026-01-01T00:00:00.000Z",
  updatedAt: "2026-01-01T00:00:00.000Z",
});

const makeAttempt = (participant: Participant, ecoScore: number, status: AttemptState["status"] = "submitted"): AttemptState => ({
  id: `attempt-${participant.id}`,
  participantId: participant.id,
  participantCode: participant.participantCode,
  status,
  startedAt: "2026-01-01T00:00:00.000Z",
  submittedAt: status === "submitted" ? "2026-01-01T00:05:00.000Z" : undefined,
  lastSavedAt: "2026-01-01T00:05:00.000Z",
  scientificResponses: { 1: 'Jawaban utuh, dengan koma, "kutipan", dan baris kedua.' },
  ecoResponses: Object.fromEntries(Array.from({ length: 24 }, (_, index) => [index + 1, ecoScore])),
  usabilityResponses: { 1: 4 },
  usabilityOpen: { mostHelpful: "Navigasi jelas", encounteredProblems: "" },
});

function makeStore() {
  const store = emptyDemoStore();
  const p1 = makeParticipant("p1", "001");
  const p2 = makeParticipant("p2", "002");
  store.participants.push(p1, p2);
  store.attempts.push(makeAttempt(p1, 1), makeAttempt(p2, 5));
  store.raterScores.push(
    { id: "r1-score", attemptId: "attempt-p1", questionId: 1, raterId: "rater1", fluencyScore: 2, flexibilityScore: 3, notes: "Catatan rater 1", scoredAt: "2026-01-02T00:00:00.000Z" },
    { id: "r2-score", attemptId: "attempt-p1", questionId: 1, raterId: "rater2", fluencyScore: 2, flexibilityScore: 4, notes: "Catatan rater 2", scoredAt: "2026-01-02T00:00:00.000Z" },
  );
  return store;
}

test("scientific creativity retains exactly fourteen text-first questions", () => {
  assert.equal(SCIENCE_QUESTIONS.length, 14);
  assert.deepEqual(SCIENCE_QUESTIONS.map((question) => question.number), Array.from({ length: 14 }, (_, index) => index + 1));
  assert.ok(SCIENCE_QUESTIONS.every((question) => question.prompt.trim().length > 0 && !("illustrationPath" in question)));
});

test("Cronbach alpha uses complete valid submitted participants and a real variance formula", () => {
  const store = makeStore();
  const summary = getEcoSummary(store.attempts);
  assert.equal(summary.mean, 3);
  assert.equal(summary.completeParticipants, 2);
  assert.ok(Math.abs((summary.alpha ?? 0) - 1) < 1e-12);

  const insufficient = getEcoSummary([makeAttempt(store.participants[0], 1)]);
  assert.equal(insufficient.alpha, null);
  assert.equal(getEcoSummary([]).mean, null);
});

test("percentage agreement excludes incomplete pairs and invalid rating values", () => {
  const store = makeStore();
  const summary = getIrrSummary(store);
  assert.equal(summary.total, 2);
  assert.equal(summary.matched, 1);
  assert.equal(summary.agreement, 50);

  store.raterScores = store.raterScores.slice(0, 1);
  assert.equal(getIrrSummary(store).total, 0);
});

test("export datasets use required headers, preserve text, and keep missing scores blank", () => {
  const datasets = createResearchDatasets(makeStore());
  assert.deepEqual(datasets.Data_Peserta.headers, [
    "participant_id", "kode_peserta", "nama_atau_inisial", "sekolah", "kelas", "waktu_mulai", "waktu_submit", "status_asesmen",
  ]);
  assert.deepEqual(datasets.SC_Respons.headers, [
    "participant_id", "kode_peserta", "nomor_soal", "indikator", "jawaban_teks", "file_gambar", "waktu_simpan",
  ]);
  assert.deepEqual(datasets.Eco_Religious.headers.slice(0, 4), ["participant_id", "kode_peserta", "ER01", "ER02"]);
  assert.deepEqual(datasets.Usability.headers.slice(0, 4), ["participant_id", "kode_peserta", "US01", "US02"]);
  assert.equal(datasets.SC_Respons.rows[0].jawaban_teks, 'Jawaban utuh, dengan koma, "kutipan", dan baris kedua.');
  assert.equal(datasets.Usability.rows[0].US02, null);
  assert.equal(datasets.SC_Skor_R1.rows[0].fluency, 2);
  assert.equal(datasets.SC_Skor_R2.rows[0].fluency, 2);
  assert.equal(datasets.IRR.rows.length, 2);
  assert.equal(datasets.SPSS_Eco_Wide.rows.length, 2);
  assert.equal(datasets.SPSS_Usability_Wide.rows.length, 2);
  assert.equal(datasets.SPSS_SC_Rater1_Wide.rows.length, 2);
  assert.equal(datasets.SPSS_SC_Rater2_Wide.rows.length, 2);
  assert.equal(datasets.SPSS_IRR_Wide.rows.length, 2);
  assert.match(createCsvContent(datasets.SC_Respons), /Jawaban utuh, dengan koma/);
});

test("demo seed data is excluded while research rows remain exportable", () => {
  const store = makeStore();
  const demoParticipant = makeParticipant("demo-participant-99", "DEMO-99");
  store.participants.push(demoParticipant);
  store.attempts.push({
    ...makeAttempt(demoParticipant, 5),
    id: "demo-attempt-99",
  });
  const filtered = getResearchStore(store);
  assert.equal(filtered.participants.length, 2);
  assert.equal(filtered.attempts.length, 2);
  assert.equal(createResearchDatasets(store).Data_Peserta.rows.length, 2);
});

test("Excel workbook creates separate frozen, filtered worksheets", async () => {
  const store = makeStore();
  const buffer = await createResearchWorkbook(store);
  const workbook = new ExcelJS.Workbook();
  await workbook.xlsx.load(buffer as ExcelJS.Buffer);
  assert.ok(workbook.getWorksheet("Data_Peserta"));
  assert.ok(workbook.getWorksheet("SPSS_Eco_Wide"));
  const participantSheet = workbook.getWorksheet("Data_Peserta");
  assert.equal(participantSheet?.views[0].state, "frozen");
  assert.ok(participantSheet?.autoFilter);
  assert.equal(participantSheet?.getRow(1).getCell(1).value, "participant_id");
});
