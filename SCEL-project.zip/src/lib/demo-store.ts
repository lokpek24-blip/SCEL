export type Participant = {
  id: string;
  participantCode: string;
  nameOrInitial: string;
  school: string;
  className: string;
  consent: boolean;
  createdAt: string;
  updatedAt: string;
};

export type AttemptState = {
  id: string;
  participantId: string;
  participantCode: string;
  status: "in_progress" | "submitted";
  startedAt: string;
  submittedAt?: string;
  lastSavedAt: string;
  scientificResponses: Record<number, string>;
  drawingResponses?: Record<number, string>;
  ecoResponses: Record<number, number>;
  usabilityResponses: Record<number, number>;
  usabilityOpen: { mostHelpful: string; encounteredProblems: string };
};

export type DemoStore = {
  participants: Participant[];
  attempts: AttemptState[];
  teacherInterviews: Array<{ id: string; school: string; teacherInitial: string; interviewDate: string; interviewer: string; responses: Record<string, string>; fieldNotes: string; createdAt: string }>;
  needsObservations: Array<{ id: string; school: string; observer: string; observationDate: string; className: string; material: string; observations: Record<string, string>; discussionNotes: string; conclusion: string; createdAt: string }>;
  raterScores: Array<{ id: string; attemptId: string; questionId: number; raterId: "rater1" | "rater2"; fluencyScore?: number; flexibilityScore?: number; originalityScore?: number; notes: string; scoredAt: string }>;
  validationScores: Array<{ id: string; validatorCode: string; validatorDomain: string; itemCode: string; score: number; comments: string; createdAt: string }>;
};

export const DEMO_STORAGE_KEY = "scel-demo-store-v1";

export const emptyDemoStore = (): DemoStore => ({
  participants: [],
  attempts: [],
  teacherInterviews: [],
  needsObservations: [],
  raterScores: [],
  validationScores: [],
});

export function readDemoStore(): DemoStore {
  if (typeof window === "undefined") return emptyDemoStore();
  const raw = window.localStorage.getItem(DEMO_STORAGE_KEY);
  if (!raw) {
    const seeded = seedDemoStore();
    window.localStorage.setItem(DEMO_STORAGE_KEY, JSON.stringify(seeded));
    return seeded;
  }

  try {
    const parsed = JSON.parse(raw) as DemoStore;
    return {
      participants: parsed.participants ?? [],
      attempts: (parsed.attempts ?? []).map((attempt) => ({
        ...attempt,
        drawingResponses: attempt.drawingResponses ?? {},
      })),
      teacherInterviews: parsed.teacherInterviews ?? [],
      needsObservations: parsed.needsObservations ?? [],
      raterScores: parsed.raterScores ?? [],
      validationScores: parsed.validationScores ?? [],
    };
  } catch {
    const seeded = seedDemoStore();
    window.localStorage.setItem(DEMO_STORAGE_KEY, JSON.stringify(seeded));
    return seeded;
  }
}

export function writeDemoStore(store: DemoStore) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(DEMO_STORAGE_KEY, JSON.stringify(store));
}

export function seedDemoStore(): DemoStore {
  const today = new Date().toISOString();
  const participantA: Participant = {
    id: "demo-participant-1",
    participantCode: "SCEL-001",
    nameOrInitial: "A. Putri",
    school: "SMAN 1 Bandung",
    className: "XI MIPA 2",
    consent: true,
    createdAt: today,
    updatedAt: today,
  };

  const participantB: Participant = {
    id: "demo-participant-2",
    participantCode: "SCEL-002",
    nameOrInitial: "R. Ardi",
    school: "SMAN 3 Yogyakarta",
    className: "XII IPA 1",
    consent: true,
    createdAt: today,
    updatedAt: today,
  };

  const attemptA: AttemptState = {
    id: "demo-attempt-1",
    participantId: participantA.id,
    participantCode: participantA.participantCode,
    status: "submitted",
    startedAt: today,
    submittedAt: today,
    lastSavedAt: today,
    scientificResponses: { 1: "Saya akan memanfaatkan botol plastik untuk membuat model rangkaian lampu sederhana.", 2: "Kabel bekas bisa dibuat sebagai alat eksperimen membandingkan panjang kabel.", 3: "Bagaimana panjang kabel memengaruhi daya lampu?", 4: "Apakah beban motor memengaruhi arus?", 5: "Jika hambatan nol, arus sangat besar dan panas menumpuk.", 6: "Sistem DC pintar bisa menyesuaikan kebutuhan lampu dan kipas.", 7: "Saya menambah LED indikator dan pengatur otomatis untuk hemat energi.", 8: "Menggunakan driver LED agar hemat energi dengan kecerahan tetap baik.", 9: "Gunakan baterai cadangan dan efisiensi lampu LED.", 10: "Mengoptimalkan pompa dengan waktu operasi singkat.", 11: "Nyalakan lampu, ubah panjang kabel, ukur arus dengan amperemeter.", 12: "Bandingkan buah jeruk, lemon, dan tomat.", 13: "Charger portabel yang menggunakan panel surya kecil.", 14: "Lampu darurat dengan baterai lithium dan sensor cahaya.", },
    ecoResponses: { 1: 5, 2: 5, 3: 4, 4: 5, 5: 4, 6: 5, 7: 4, 8: 5, 9: 3, 10: 5, 11: 4, 12: 5, 13: 5, 14: 4, 15: 5, 16: 4, 17: 5, 18: 4, 19: 5, 20: 5, 21: 4, 22: 5, 23: 4, 24: 5 },
    usabilityResponses: { 1: 5, 2: 5, 3: 5, 4: 4, 5: 5, 6: 5, 7: 4, 8: 5, 9: 4, 10: 5, 11: 4, 12: 5, 13: 5, 14: 5, 15: 5 },
    usabilityOpen: { mostHelpful: "Urutan soal mudah diikuti dan tampilan bersih.", encounteredProblems: "Tidak ada kendala besar." },
  };

  const attemptB: AttemptState = {
    id: "demo-attempt-2",
    participantId: participantB.id,
    participantCode: participantB.participantCode,
    status: "in_progress",
    startedAt: today,
    lastSavedAt: today,
    scientificResponses: { 1: "Botol plastik dapat dibuat prototipe lampu urban.", 2: "Lampu LED bekas dapat dibuat indikator energi.", 3: "Mengapa kabel panjang membuat lampu redup?", 4: "Apakah beban memengaruhi kecepatan motor?" },
    ecoResponses: {},
    usabilityResponses: {},
    usabilityOpen: { mostHelpful: "", encounteredProblems: "" },
  };

  return {
    participants: [participantA, participantB],
    attempts: [attemptA, attemptB],
    teacherInterviews: [],
    needsObservations: [],
    raterScores: [
      { id: "demo-rater-1", attemptId: attemptA.id, questionId: 1, raterId: "rater1", fluencyScore: 3, flexibilityScore: 2, originalityScore: 3, notes: "Jawaban relevan namun masih umum.", scoredAt: today },
      { id: "demo-rater-2", attemptId: attemptA.id, questionId: 1, raterId: "rater2", fluencyScore: 3, flexibilityScore: 2, originalityScore: 3, notes: "Sama dengan rater 1.", scoredAt: today },
    ],
    validationScores: [
      { id: "demo-validation-1", validatorCode: "V-01", validatorDomain: "Fisika/SCEL", itemCode: "Q01", score: 4, comments: "Sesuai dengan indikator material.", createdAt: today },
    ],
  };
}

export function ensureDemoModeSeeded() {
  if (typeof window === "undefined") return;
  const current = readDemoStore();
  if (!current.participants.length && !current.attempts.length) {
    writeDemoStore(seedDemoStore());
  }
}
