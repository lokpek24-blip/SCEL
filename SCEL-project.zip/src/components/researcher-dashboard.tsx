"use client";

import { useMemo, useState } from "react";
import { DEMO_MODE_LABEL, ECO_ITEMS, QUESTION_DIMENSIONS, RESEARCHER_USERS, SCIENCE_QUESTIONS, USABILITY_ITEMS } from "@/data/instruments";
import { readDemoStore, writeDemoStore } from "@/lib/demo-store";
import { getEcoSummary, getIrrSummary, getLatestAttempt, getPendingRatingCount, getResearchStore, getRaterScoreMap } from "@/lib/research-analytics";
import { createCsvContent, createResearchDatasets, createResearchWorkbook, type DatasetName } from "@/lib/research-export";

type ResearchTab =
  | "dashboard"
  | "participants"
  | "responses"
  | "manual"
  | "irr"
  | "eco"
  | "usability"
  | "validation"
  | "analysis"
  | "interview"
  | "observation"
  | "visualization"
  | "export"
  | "settings";

const navigationGroups: { title: string; items: { id: ResearchTab; label: string }[] }[] = [
  { title: "Ringkasan", items: [{ id: "dashboard", label: "Dashboard" }] },
  { title: "Data Penelitian", items: [
    { id: "participants", label: "Data Siswa" },
    { id: "responses", label: "Respons Scientific Creativity" },
    { id: "eco", label: "Eco-Religious" },
    { id: "usability", label: "Usability" },
  ] },
  { title: "Penilaian", items: [
    { id: "manual", label: "Manual Scoring" },
    { id: "irr", label: "Inter-Rater Reliability" },
  ] },
  { title: "Validasi Instrumen", items: [
    { id: "validation", label: "Validasi Ahli" },
    { id: "analysis", label: "Analisis Aiken's V" },
  ] },
  { title: "Data Pendukung", items: [
    { id: "interview", label: "Wawancara Guru" },
    { id: "observation", label: "Observasi Analisis Kebutuhan" },
  ] },
  { title: "Analisis dan Ekspor", items: [
    { id: "visualization", label: "Visualisasi Data" },
    { id: "export", label: "Export Data" },
  ] },
  { title: "Pengaturan", items: [{ id: "settings", label: "Pengaturan Instrumen" }] },
];

function getStoredUser() {
  if (typeof window === "undefined") return null;
  const raw = window.localStorage.getItem("scel-researcher-user");
  return raw ? JSON.parse(raw) : null;
}

export default function ResearcherDashboard({ initialTab = "dashboard" }: { initialTab?: ResearchTab }) {
  const [activeTab, setActiveTab] = useState<ResearchTab>(initialTab);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loginError, setLoginError] = useState("");
  const [authUser, setAuthUser] = useState<{ username: string; role: string } | null>(getStoredUser);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [collapsedGroups, setCollapsedGroups] = useState<Record<string, boolean>>({});
  const [exportState, setExportState] = useState("");
  const [scoringMessage, setScoringMessage] = useState("");
  const [selectedAttemptId, setSelectedAttemptId] = useState("");
  const [selectedRater, setSelectedRater] = useState<"rater1" | "rater2">("rater1");
  const [csvDataset, setCsvDataset] = useState<DatasetName>("Data_Peserta");
  const store = getResearchStore(readDemoStore());
  const datasets = useMemo(() => createResearchDatasets(store), [store]);

  const login = () => {
    const match = RESEARCHER_USERS.find(
      (entry) => entry.username === username.trim() && entry.password === password,
    );

    if (!match) {
      setLoginError("Username atau password tidak valid. Gunakan akun demo berikut: admin/admin123, rater/rater123, researcher/research123.");
      return;
    }

    const payload = { username: match.username, role: match.role };
    if (typeof window !== "undefined") {
      window.localStorage.setItem("scel-researcher-user", JSON.stringify(payload));
    }
    setAuthUser(payload);
    setLoginError("");
    setActiveTab("dashboard");
  };

  const logout = () => {
    if (typeof window !== "undefined") window.localStorage.removeItem("scel-researcher-user");
    setAuthUser(null);
    setUsername("");
    setPassword("");
    setActiveTab("dashboard");
  };

  const totalParticipants = store.participants.length;
  const latestAttempts = store.participants.map((participant) => getLatestAttempt(store.attempts, participant.id)).filter((attempt) => attempt !== undefined);
  const completedParticipants = latestAttempts.filter((attempt) => attempt.status === "submitted").length;
  const incompleteParticipants = totalParticipants - completedParticipants;
  const pendingScores = getPendingRatingCount(store);
  const submittedAttempts = store.attempts.filter((attempt) => attempt.status === "submitted");
  const ecoSummary = getEcoSummary(store.attempts);
  const irrSummary = getIrrSummary(store);
  const raterScoreMap = getRaterScoreMap(store);
  const expectedRaterScores = submittedAttempts.reduce(
    (count) => count + Object.values(QUESTION_DIMENSIONS).reduce((sum, dimensions) => sum + dimensions.length, 0) * 2,
    0,
  );
  const countRatedFor = (raterId: "r1" | "r2") => [...raterScoreMap.values()].filter((pair) => pair[raterId] !== undefined).length;
  const rater1Count = countRatedFor("r1");
  const rater2Count = countRatedFor("r2");
  const validEcoScores = submittedAttempts.flatMap((attempt) =>
    ECO_ITEMS.map((item) => attempt.ecoResponses[item.id]).filter((score): score is number => score !== undefined && Number.isInteger(score) && score >= 1 && score <= 5),
  );
  const avgEco = validEcoScores.length
    ? validEcoScores.reduce((sum, score) => sum + score, 0) / validEcoScores.length
    : null;
  const validUsabilityScores = submittedAttempts.flatMap((attempt) =>
    USABILITY_ITEMS.map((item) => attempt.usabilityResponses[item.id]).filter((score): score is number => score !== undefined && Number.isInteger(score) && score >= 1 && score <= 5),
  );
  const avgUsability = validUsabilityScores.length
    ? validUsabilityScores.reduce((sum, score) => sum + score, 0) / validUsabilityScores.length
    : null;
  const validScientificScores = store.raterScores.flatMap((score) =>
    [score.fluencyScore, score.flexibilityScore, score.originalityScore].filter((value): value is number => value !== undefined && Number.isInteger(value) && value >= 1 && value <= 4),
  );
  const averageScientific = validScientificScores.length
    ? validScientificScores.reduce((sum, value) => sum + value, 0) / validScientificScores.length
    : null;
  const aikenData = useMemo(() => {
    const grouped = new Map<string, number[]>();
    store.validationScores.forEach((score) => {
      if (!Number.isInteger(score.score) || score.score < 1 || score.score > 5) return;
      const key = `${score.validatorDomain}||${score.itemCode}`;
      grouped.set(key, [...(grouped.get(key) ?? []), score.score]);
    });
    return [...grouped.entries()].map(([key, scores]) => {
      const [domain, itemCode] = key.split("||");
      const value = scores.length >= 3
        ? scores.reduce((sum, score) => sum + (score - 1), 0) / (scores.length * 4)
        : null;
      return { id: key, domain, itemCode, scores, value };
    });
  }, [store.validationScores]);

  const downloadCsv = (sheetName: DatasetName) => {
    const content = createCsvContent(datasets[sheetName]);
    const blob = new Blob(["\uFEFF", content], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `${sheetName}.csv`;
    anchor.click();
    URL.revokeObjectURL(url);
  };

  const downloadWorkbook = async () => {
    setExportState("Menyiapkan workbook Excel...");
    try {
      const workbook = await createResearchWorkbook(store, datasets);
      const blob = new Blob([workbook], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement("a");
      anchor.href = url;
      anchor.download = "SCEL_Data_Penelitian.xlsx";
      anchor.click();
      URL.revokeObjectURL(url);
      setExportState("Workbook Excel berhasil dibuat dan diunduh.");
    } catch {
      setExportState("Workbook gagal dibuat. Coba unduh CSV terpisah atau periksa ruang penyimpanan browser.");
    }
  };

  const downloadSpssWorkbook = async () => {
    const spssNames: DatasetName[] = [
      "SPSS_Eco_Wide",
      "SPSS_Usability_Wide",
      "SPSS_SC_Rater1_Wide",
      "SPSS_SC_Rater2_Wide",
      "SPSS_IRR_Wide",
    ];
    setExportState("Menyiapkan workbook SPSS...");
    try {
      const spssDatasets = Object.fromEntries(spssNames.map((name) => [name, datasets[name]])) as Pick<typeof datasets, typeof spssNames[number]>;
      const workbook = await createResearchWorkbook(store, spssDatasets);
      const blob = new Blob([workbook], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement("a");
      anchor.href = url;
      anchor.download = "SCEL_SPSS_Wide.xlsx";
      anchor.click();
      URL.revokeObjectURL(url);
      setExportState("Workbook SPSS berhasil dibuat dan diunduh.");
    } catch {
      setExportState("Workbook SPSS gagal dibuat. Coba unduh CSV terpisah.");
    }
  };

  const renderNavigation = (isMobile = false) => (
    <nav aria-label="Navigasi dashboard admin" className="space-y-3">
      {navigationGroups.map((group) => {
        const isCollapsed = collapsedGroups[group.title] ?? false;
        return (
          <section key={group.title}>
            <button
              type="button"
              aria-expanded={!isCollapsed}
              onClick={() => setCollapsedGroups((current) => ({ ...current, [group.title]: !isCollapsed }))}
              className="flex w-full items-center justify-between px-3 py-2 text-left text-xs font-bold uppercase tracking-wider text-slate-500"
            >
              <span>{group.title}</span>
              <span aria-hidden="true">{isCollapsed ? "+" : "−"}</span>
            </button>
            {!isCollapsed ? (
              <div className="space-y-1">
                {group.items.map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    aria-current={activeTab === item.id ? "page" : undefined}
                    onClick={() => {
                      setActiveTab(item.id);
                      if (isMobile) setDrawerOpen(false);
                    }}
                    className={`w-full rounded-xl px-3 py-2.5 text-left text-sm leading-5 transition ${
                      activeTab === item.id
                        ? "bg-blue-700 font-semibold text-white"
                        : "text-slate-700 hover:bg-blue-50 hover:text-blue-800"
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            ) : null}
          </section>
        );
      })}
    </nav>
  );

  const renderDashboard = () => (
    <div className="space-y-6">
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Total peserta" value={String(totalParticipants)} accent="blue" />
        <StatCard label="Asesmen selesai" value={String(completedParticipants)} accent="emerald" />
        <StatCard label="Belum selesai" value={String(incompleteParticipants)} accent="amber" />
        <StatCard label="Respons menunggu penilaian" value={String(pendingScores)} accent="violet" />
      </div>

      <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
        <h2 className="text-lg font-bold text-slate-900">Progres asesmen</h2>
        <p className="mt-1 text-sm text-slate-600">Proporsi peserta dengan asesmen yang sudah dikirim.</p>
        <div className="mt-4 flex items-center gap-3">
          <div
            role="progressbar"
            aria-valuemin={0}
            aria-valuemax={totalParticipants}
            aria-valuenow={completedParticipants}
            aria-label="Progres asesmen peserta"
            className="h-3 flex-1 overflow-hidden rounded-full bg-slate-100"
          >
            <div className="h-full rounded-full bg-emerald-600" style={{ width: `${totalParticipants ? (completedParticipants / totalParticipants) * 100 : 0}%` }} />
          </div>
          <span className="whitespace-nowrap text-sm font-semibold text-slate-700">{completedParticipants} / {totalParticipants} selesai</span>
        </div>
      </section>

      <div className="grid gap-4 lg:grid-cols-2">
        <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
          <h2 className="text-lg font-bold text-slate-900">Status penskoran</h2>
          <p className="mt-1 text-sm text-slate-600">Skor valid dari asesmen yang telah dikirim.</p>
          <div className="mt-4 space-y-3">
            <div className="flex justify-between gap-2 text-sm"><span>Rater 1</span><strong>{expectedRaterScores ? `${rater1Count} / ${expectedRaterScores}` : "Belum tersedia"}</strong></div>
            <div className="h-2 rounded-full bg-slate-100"><div className="h-2 rounded-full bg-blue-600" style={{ width: `${expectedRaterScores ? Math.min(rater1Count / expectedRaterScores * 100, 100) : 0}%` }} /></div>
            <div className="flex justify-between gap-2 text-sm"><span>Rater 2</span><strong>{expectedRaterScores ? `${rater2Count} / ${expectedRaterScores}` : "Belum tersedia"}</strong></div>
            <div className="h-2 rounded-full bg-slate-100"><div className="h-2 rounded-full bg-violet-600" style={{ width: `${expectedRaterScores ? Math.min(rater2Count / expectedRaterScores * 100, 100) : 0}%` }} /></div>
          </div>
        </section>

        <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
          <h2 className="text-lg font-bold text-slate-900">Aktivitas terbaru</h2>
          {store.attempts.length ? (
            <ul className="mt-3 divide-y divide-slate-100">
              {[...store.attempts].sort((a, b) => b.lastSavedAt.localeCompare(a.lastSavedAt)).slice(0, 4).map((attempt) => (
                <li key={attempt.id} className="flex flex-wrap items-center justify-between gap-2 py-2 text-sm">
                  <span className="font-medium text-slate-800">{attempt.participantCode}</span>
                  <span className="text-slate-500">{attempt.status === "submitted" ? "Selesai" : "Dalam proses"} · {new Date(attempt.lastSavedAt).toLocaleString("id-ID")}</span>
                </li>
              ))}
            </ul>
          ) : <p className="mt-3 text-sm text-slate-600">Belum ada aktivitas peserta.</p>}
        </section>
      </div>

      <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
        <h2 className="text-lg font-bold text-slate-900">Akses cepat</h2>
        <div className="mt-3 flex flex-wrap gap-2">
          <button type="button" onClick={() => setActiveTab("participants")} className="btn-secondary">Data Siswa</button>
          <button type="button" onClick={() => setActiveTab("manual")} className="btn-secondary">Manual Scoring</button>
          <button type="button" onClick={() => setActiveTab("export")} className="btn-secondary">Export Data</button>
        </div>
      </section>

      <p className="text-xs text-slate-500">{DEMO_MODE_LABEL}: data tersimpan di browser ini dan bukan database penelitian produksi. Data bawaan demonstrasi tidak dihitung dalam ringkasan.</p>
    </div>
  );

  const renderParticipants = () => (
    <div className="space-y-6 rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
      <div>
        <p className="text-sm font-semibold uppercase tracking-[0.2em] text-blue-700">Data siswa</p>
        <h2 className="mt-2 text-2xl font-bold text-slate-900">Daftar peserta</h2>
      </div>
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-slate-200 text-left text-sm">
          <thead className="bg-slate-100 text-slate-700">
            <tr>
              <th className="px-3 py-2">Kode</th>
              <th className="px-3 py-2">Nama</th>
              <th className="px-3 py-2">Sekolah</th>
              <th className="px-3 py-2">Kelas</th>
              <th className="px-3 py-2">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200 bg-white">
            {store.participants.map((participant) => {
              const attempt = store.attempts.find((item) => item.participantId === participant.id);
              return (
                <tr key={participant.id}>
                  <td className="px-3 py-2">{participant.participantCode}</td>
                  <td className="px-3 py-2">{participant.nameOrInitial}</td>
                  <td className="px-3 py-2">{participant.school}</td>
                  <td className="px-3 py-2">{participant.className}</td>
                  <td className="px-3 py-2">{attempt?.status === "submitted" ? "Selesai" : "Belum selesai"}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );

  const renderResponses = () => (
    <section className="space-y-4 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
      <div>
        <h2 className="text-xl font-bold text-slate-900">Respons Scientific Creativity</h2>
        <p className="mt-1 text-sm text-slate-600">Jawaban teks ditampilkan utuh; dataset ekspor menyediakan satu baris per peserta dan soal.</p>
      </div>
      {store.attempts.length ? (
        <div className="overflow-x-auto rounded-xl border border-slate-200">
          <table className="min-w-full divide-y divide-slate-200 text-left text-sm">
            <thead className="bg-slate-100 text-slate-700"><tr><th className="px-3 py-2">Kode peserta</th><th className="px-3 py-2">Soal</th><th className="px-3 py-2">Indikator</th><th className="px-3 py-2">Jawaban</th><th className="px-3 py-2">Gambar</th></tr></thead>
            <tbody className="divide-y divide-slate-100">
              {store.attempts.flatMap((attempt) => SCIENCE_QUESTIONS.map((question) => (
                <tr key={`${attempt.id}-${question.number}`} className="align-top">
                  <td className="whitespace-nowrap px-3 py-3">{attempt.participantCode}</td>
                  <td className="px-3 py-3">{question.number}</td>
                  <td className="px-3 py-3">{question.indicator}</td>
                  <td className="max-w-xl whitespace-pre-wrap px-3 py-3">{attempt.scientificResponses[question.number] ?? ""}</td>
                  <td className="px-3 py-3">{attempt.drawingResponses?.[question.number] ? "Terlampir" : "—"}</td>
                </tr>
              )))}
            </tbody>
          </table>
        </div>
      ) : <p className="rounded-xl bg-slate-50 p-4 text-sm text-slate-600">Belum ada respons penelitian.</p>}
    </section>
  );

  const renderManual = () => (
    (() => {
      const scoringAttempts = store.attempts.filter((attempt) => attempt.status === "submitted");
      const currentAttempt = scoringAttempts.find((attempt) => attempt.id === selectedAttemptId) ?? scoringAttempts[0];
      const saveRaterEntry = (questionId: number, field: "fluencyScore" | "flexibilityScore" | "originalityScore" | "notes", value: string) => {
        if (!currentAttempt) return;
        const numericValue = value === "" ? undefined : Number(value);
        if (field !== "notes" && numericValue !== undefined && (!Number.isInteger(numericValue) || numericValue < 1 || numericValue > 4)) {
          setScoringMessage("Skor harus bilangan bulat dari 1 sampai 4.");
          return;
        }
        try {
          const nextStore = readDemoStore();
          const index = nextStore.raterScores.findIndex((score) =>
            score.attemptId === currentAttempt.id && score.questionId === questionId && score.raterId === selectedRater,
          );
          const existing = index >= 0 ? nextStore.raterScores[index] : {
            id: `score-${currentAttempt.id}-${questionId}-${selectedRater}`,
            attemptId: currentAttempt.id,
            questionId,
            raterId: selectedRater,
            notes: "",
            scoredAt: new Date().toISOString(),
          };
          const updated = {
            ...existing,
            ...(field === "notes" ? { notes: value } : { [field]: numericValue }),
            scoredAt: new Date().toISOString(),
          };
          if (index >= 0) nextStore.raterScores[index] = updated;
          else nextStore.raterScores.push(updated);
          writeDemoStore(nextStore);
          setScoringMessage("Skor tersimpan di browser.");
        } catch {
          setScoringMessage("Skor gagal disimpan. Periksa penyimpanan browser lalu coba lagi.");
        }
      };

      return (
        <section className="space-y-5 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
          <div>
            <h2 className="text-xl font-bold text-slate-900">Manual Scoring</h2>
            <p className="mt-1 text-sm text-slate-600">Skala rubrik 1–4. Nilai kosong tidak diperlakukan sebagai nol.</p>
          </div>
          <div className="grid gap-3 md:grid-cols-2">
            <label className="text-sm font-medium text-slate-700">Peserta
              <select value={currentAttempt?.id ?? ""} onChange={(event) => setSelectedAttemptId(event.target.value)} className="mt-1 w-full rounded-xl border border-slate-300 bg-white px-3 py-2">
                {scoringAttempts.length ? scoringAttempts.map((attempt) => <option key={attempt.id} value={attempt.id}>{attempt.participantCode}</option>) : <option value="">Belum ada asesmen selesai</option>}
              </select>
            </label>
            <label className="text-sm font-medium text-slate-700">Penilai
              <select value={selectedRater} onChange={(event) => setSelectedRater(event.target.value as "rater1" | "rater2")} className="mt-1 w-full rounded-xl border border-slate-300 bg-white px-3 py-2">
                <option value="rater1">Rater 1</option>
                <option value="rater2">Rater 2</option>
              </select>
            </label>
          </div>
          {scoringMessage ? <p role="status" className="text-sm text-slate-600">{scoringMessage}</p> : null}
          {currentAttempt ? SCIENCE_QUESTIONS.map((question) => {
            const score = store.raterScores.find((entry) => entry.attemptId === currentAttempt.id && entry.questionId === question.number && entry.raterId === selectedRater);
            const response = currentAttempt.scientificResponses[question.number] ?? "";
            return (
              <article key={question.id} className="space-y-3 rounded-xl border border-slate-200 p-4">
                <h3 className="font-semibold text-slate-900">Soal {question.number}: {question.indicator}</h3>
                <p className="whitespace-pre-wrap rounded-lg bg-slate-50 p-3 text-sm text-slate-700">{response || "Tidak ada jawaban teks."}</p>
                <div className="grid gap-3 sm:grid-cols-3">
                  {QUESTION_DIMENSIONS[question.number].map((dimension) => {
                    const field = `${dimension}Score` as "fluencyScore" | "flexibilityScore" | "originalityScore";
                    return (
                      <label key={dimension} className="text-sm text-slate-700">{dimension}
                        <input type="number" min={1} max={4} step={1} value={score?.[field] ?? ""} onChange={(event) => saveRaterEntry(question.number, field, event.target.value)} className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2" />
                      </label>
                    );
                  })}
                </div>
                <label className="block text-sm text-slate-700">Catatan rater
                  <textarea rows={2} value={score?.notes ?? ""} onChange={(event) => saveRaterEntry(question.number, "notes", event.target.value)} className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2" />
                </label>
              </article>
            );
          }) : <p className="rounded-xl bg-slate-50 p-4 text-sm text-slate-600">Belum ada asesmen selesai yang dapat dinilai.</p>}
        </section>
      );
    })()
  );

  const renderIrr = () => (
    <div className="space-y-6 rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
      <div>
        <h2 className="text-xl font-bold text-slate-900">Inter-Rater Reliability</h2>
        <p className="mt-1 text-sm text-slate-600">Percentage Agreement dihitung per pasangan skor dimensi yang lengkap dan valid.</p>
      </div>
      <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
        <p className="text-base text-slate-700">Jumlah pasangan skor valid: {irrSummary.total}</p>
        <p className="text-base text-slate-700">Persetujuan: {irrSummary.matched}</p>
        <p className="text-xl font-bold text-slate-900">Percentage Agreement = {irrSummary.agreement === null ? "Data belum cukup" : `${irrSummary.agreement.toFixed(2)}%`}</p>
        <p className="mt-3 text-sm text-slate-600">Target penelitian: ≥80%. Skor yang belum dinilai tidak dianggap nol. Data demo dikecualikan.</p>
      </div>
    </div>
  );

  const renderEco = () => (
    <section className="space-y-5 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
      <div>
        <h2 className="text-xl font-bold text-slate-900">Eco-Religious</h2>
        <p className="mt-1 text-sm text-slate-600">Rerata item dan reliabilitas Cronbach’s Alpha adalah statistik yang berbeda.</p>
      </div>
      <div className="grid gap-3 sm:grid-cols-2">
        <StatCard label={`Rerata skor item (${ecoSummary.validResponses} respons valid)`} value={avgEco === null ? "Belum tersedia" : avgEco.toFixed(2)} accent="green" />
        <StatCard label={`Cronbach’s Alpha (${ecoSummary.completeParticipants} kasus lengkap)`} value={ecoSummary.alpha === null ? "Data belum cukup" : ecoSummary.alpha.toFixed(3)} accent="violet" />
      </div>
      <div className="overflow-x-auto rounded-xl border border-slate-200">
        <table className="min-w-full divide-y divide-slate-200 text-left text-sm">
          <thead className="bg-slate-100 text-slate-700"><tr><th className="px-3 py-2">Dimensi</th><th className="px-3 py-2">Rerata respons valid</th><th className="px-3 py-2">Jumlah respons</th></tr></thead>
          <tbody className="divide-y divide-slate-100">
            {Array.from(new Set(ECO_ITEMS.map((item) => item.dimension))).map((dimension) => {
              const items = ECO_ITEMS.filter((item) => item.dimension === dimension);
              const scores = submittedAttempts.flatMap((attempt) => items.map((item) => attempt.ecoResponses[item.id]).filter((value) => Number.isInteger(value) && value >= 1 && value <= 5));
              const mean = scores.length ? scores.reduce((sum, value) => sum + value, 0) / scores.length : null;
              return <tr key={dimension}><td className="px-3 py-2">{dimension}</td><td className="px-3 py-2">{mean === null ? "Belum tersedia" : mean.toFixed(2)}</td><td className="px-3 py-2">{scores.length}</td></tr>;
            })}
          </tbody>
        </table>
      </div>
      <p className="text-xs text-slate-500">Alpha memakai hanya asesmen submitted dengan 24 skor valid lengkap. Minimal dua kasus lengkap; data demo dikecualikan.</p>
    </section>
  );

  const renderUsabilitySection = () => (
    <section className="space-y-5 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
      <div>
        <h2 className="text-xl font-bold text-slate-900">Usability</h2>
        <p className="mt-1 text-sm text-slate-600">Ringkasan feedback dan jumlah respons tersedia.</p>
      </div>
      <div className="grid gap-3 sm:grid-cols-2">
        <StatCard label={`Rerata item valid (${validUsabilityScores.length} respons)`} value={avgUsability === null ? "Belum tersedia" : avgUsability.toFixed(2)} accent="cyan" />
        <StatCard label="Asesmen dikirim" value={String(submittedAttempts.length)} accent="blue" />
      </div>
      <div className="space-y-3">
        {submittedAttempts.map((attempt) => (
          <article key={attempt.id} className="rounded-xl border border-slate-200 p-4">
            <h3 className="font-semibold text-slate-900">{attempt.participantCode}</h3>
            <p className="mt-2 text-sm text-slate-700">Bagian terbantu: {attempt.usabilityOpen.mostHelpful || "Belum diisi"}</p>
            <p className="mt-1 text-sm text-slate-700">Kendala: {attempt.usabilityOpen.encounteredProblems || "Belum diisi"}</p>
          </article>
        ))}
        {!submittedAttempts.length ? <p className="text-sm text-slate-600">Belum ada respons usability penelitian.</p> : null}
      </div>
    </section>
  );

  const renderValidation = () => (
    <div className="space-y-6 rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
      <div>
        <p className="text-sm font-semibold uppercase tracking-[0.2em] text-blue-700">Validasi Ahli</p>
        <h2 className="mt-2 text-2xl font-bold text-slate-900">Penilaian validator</h2>
      </div>
      <div className="space-y-3">
        {aikenData.length ? aikenData.map((entry) => (
          <div key={entry.id} className="rounded-2xl border border-slate-200 bg-slate-50 p-4 text-sm text-slate-700">
            {entry.domain} • {entry.itemCode} • {entry.scores.length} skor valid • Aiken’s V: {entry.value === null ? "Data belum cukup (minimal 3 validator)" : entry.value.toFixed(3)}
          </div>
        )) : <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4 text-sm text-slate-600">Belum ada data validasi ahli.</div>}
      </div>
    </div>
  );

  const renderAnalysis = () => (
    <div className="space-y-6 rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
      <div>
        <p className="text-sm font-semibold uppercase tracking-[0.2em] text-blue-700">Aiken V</p>
        <h2 className="mt-2 text-2xl font-bold text-slate-900">Perhitungan validitas berdasarkan penilaian validator</h2>
      </div>
      <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4 text-slate-700">
        {aikenData.length ? <p>Nilai dihitung per domain dan item dengan V = Σ(rᵢ − 1) / [n(5 − 1)]; minimal tiga skor validator valid per kelompok. {aikenData.filter((entry) => entry.value !== null).length} kelompok memenuhi data minimum.</p> : <p>Belum tersedia data penilaian validator.</p>}
      </div>
    </div>
  );

  const renderInterview = () => (
    <div className="space-y-6 rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
      <div>
        <p className="text-sm font-semibold uppercase tracking-[0.2em] text-blue-700">Wawancara Guru</p>
        <h2 className="mt-2 text-2xl font-bold text-slate-900">Form input wawancara semi-terstruktur</h2>
      </div>
      <div className="rounded-2xl border border-dashed border-slate-300 bg-slate-50 p-5 text-sm text-slate-600">
        Form wawancara dapat disimpan melalui local storage demo. Isian disarankan diunggah dan diproses di database utama saat penelitian berjalan.
      </div>
    </div>
  );

  const renderObservation = () => (
    <div className="space-y-6 rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
      <div>
        <p className="text-sm font-semibold uppercase tracking-[0.2em] text-blue-700">Observasi & Analisis Kebutuhan</p>
        <h2 className="mt-2 text-2xl font-bold text-slate-900">Catatan observasi awal</h2>
      </div>
      <div className="rounded-2xl border border-dashed border-slate-300 bg-slate-50 p-5 text-sm text-slate-600">
        Form observasi tersedia dalam mode demonstrasi untuk memudahkan proses pendahuluan dan dokumentasi kebutuhan.
      </div>
    </div>
  );

  const renderVisualization = () => (
    <div className="space-y-6 rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
      <div>
        <p className="text-sm font-semibold uppercase tracking-[0.2em] text-blue-700">Visualisasi Data</p>
        <h2 className="mt-2 text-2xl font-bold text-slate-900">Ringkasan grafik</h2>
      </div>
      <div className="grid gap-4 md:grid-cols-3">
        <BarBox label="Scientific Creativity (rerata skor / 4)" value={averageScientific === null ? null : averageScientific / 4 * 100} color="bg-blue-600" />
        <BarBox label="Eco-Religious (rerata / 5)" value={avgEco === null ? null : avgEco * 20} color="bg-emerald-600" />
        <BarBox label="Usability (rerata / 5)" value={avgUsability === null ? null : avgUsability * 20} color="bg-violet-600" />
      </div>
    </div>
  );

  const renderExport = () => (
    <section className="space-y-5 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
      <div>
        <h2 className="text-xl font-bold text-slate-900">Export Data Penelitian</h2>
        <p className="mt-1 text-sm text-slate-600">Workbook berisi sheet mentah, SPSS wide, dan README_Data.</p>
      </div>
      <div className="flex flex-wrap gap-3">
        <button type="button" onClick={downloadWorkbook} className="btn-primary">Unduh workbook Excel lengkap</button>
        <button type="button" onClick={downloadSpssWorkbook} className="btn-secondary">Unduh workbook SPSS</button>
      </div>
      <div className="grid gap-3 sm:grid-cols-[minmax(0,1fr)_auto]">
        <label className="text-sm font-medium text-slate-700">Pilih satu dataset CSV
          <select value={csvDataset} onChange={(event) => setCsvDataset(event.target.value as DatasetName)} className="mt-1 w-full rounded-xl border border-slate-300 bg-white px-3 py-2">
            <optgroup label="Dataset mentah">
              {(["Data_Peserta", "SC_Respons", "SC_Skor_R1", "SC_Skor_R2", "IRR", "Eco_Religious", "Usability", "Validasi_Aiken", "Wawancara_Guru", "Observasi", "README_Data"] as DatasetName[]).map((name) => <option key={name} value={name}>{name}</option>)}
            </optgroup>
            <optgroup label="Dataset SPSS wide">
              {(["SPSS_Eco_Wide", "SPSS_Usability_Wide", "SPSS_SC_Rater1_Wide", "SPSS_SC_Rater2_Wide", "SPSS_IRR_Wide"] as DatasetName[]).map((name) => <option key={name} value={name}>{name}</option>)}
            </optgroup>
          </select>
        </label>
        <button type="button" onClick={() => downloadCsv(csvDataset)} className="btn-secondary self-end">Unduh CSV</button>
      </div>
      {exportState ? <p role="status" className="text-sm text-slate-700">{exportState}</p> : null}
      <div className="rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-900">
        Google Sheets belum dikonfigurasi. Tidak ada sinkronisasi otomatis; gunakan workbook/CSV di atas. Kredensial Google tidak boleh dimasukkan ke frontend.
      </div>
      <div className="rounded-xl bg-slate-50 p-4 text-sm text-slate-600">
        Baris demo bawaan dikecualikan. CSV memakai BOM UTF-8 agar Excel mengenali encoding, serta mengescapa prefiks yang dapat ditafsirkan sebagai formula spreadsheet.
      </div>
    </section>
  );

  const renderSettings = () => (
    <div className="space-y-6 rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
      <div>
        <p className="text-sm font-semibold uppercase tracking-[0.2em] text-blue-700">Pengaturan Instrumen</p>
        <h2 className="mt-2 text-2xl font-bold text-slate-900">Versi instrumen aktif</h2>
      </div>
      <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4 text-slate-700">
        <p><strong>SCEL-DC-v1.0-14Q</strong></p>
        <p className="mt-2">Scientific Creativity: 14 soal</p>
        <p>Eco-Religious: 24 item</p>
        <p>Usability: 15 item</p>
      </div>
    </div>
  );

  const renderContent = () => {
    if (!authUser) {
      return (
        <div className="mx-auto max-w-md rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
          <p className="text-sm font-semibold uppercase tracking-[0.2em] text-blue-700">Login Peneliti</p>
          <h2 className="mt-2 text-2xl font-bold text-slate-900">Akses dashboard</h2>
          <div className="mt-5 space-y-4">
            <label className="block text-sm font-medium text-slate-700">
              Username
              <input value={username} onChange={(event) => setUsername(event.target.value)} className="mt-1 w-full rounded-xl border border-slate-300 px-3 py-2.5" placeholder="admin" />
            </label>
            <label className="block text-sm font-medium text-slate-700">
              Password
              <input type="password" value={password} onChange={(event) => setPassword(event.target.value)} className="mt-1 w-full rounded-xl border border-slate-300 px-3 py-2.5" placeholder="••••••" />
            </label>
            {loginError ? <p className="text-sm text-red-600">{loginError}</p> : null}
            <button onClick={login} className="btn-primary w-full">Masuk</button>
          </div>
        </div>
      );
    }

    return (
      <>
        {activeTab === "dashboard" && renderDashboard()}
        {activeTab === "participants" && renderParticipants()}
        {activeTab === "responses" && renderResponses()}
        {activeTab === "manual" && renderManual()}
        {activeTab === "irr" && renderIrr()}
        {activeTab === "eco" && renderEco()}
        {activeTab === "usability" && renderUsabilitySection()}
        {activeTab === "validation" && renderValidation()}
        {activeTab === "analysis" && renderAnalysis()}
        {activeTab === "interview" && renderInterview()}
        {activeTab === "observation" && renderObservation()}
        {activeTab === "visualization" && renderVisualization()}
        {activeTab === "export" && renderExport()}
        {activeTab === "settings" && renderSettings()}
      </>
    );
  };

  return (
    <main className="mx-auto w-full max-w-[1500px] px-3 py-5 sm:px-6 sm:py-8">
      <header className="mb-5 flex flex-wrap items-center justify-between gap-3 rounded-2xl bg-gradient-to-r from-slate-900 via-blue-900 to-emerald-700 p-4 text-white shadow-lg sm:p-6">
        <div className="flex items-center gap-3">
          {authUser ? (
            <button type="button" onClick={() => setDrawerOpen(true)} className="rounded-lg border border-white/30 px-3 py-2 text-sm font-semibold text-white md:hidden" aria-label="Buka menu navigasi">
              Menu
            </button>
          ) : null}
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-blue-100">Research Dashboard</p>
            <h1 className="mt-1 text-xl font-bold sm:text-2xl">Digital Assessment SCEL</h1>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className="rounded-full border border-white/20 bg-white/10 px-3 py-1 text-xs font-semibold uppercase tracking-wide text-blue-50">{DEMO_MODE_LABEL}</span>
          {authUser ? <>
            <span className="hidden rounded-full bg-white/15 px-3 py-1 text-xs font-semibold sm:inline">{authUser.role}</span>
            <button type="button" onClick={logout} className="rounded-lg border border-white/30 px-3 py-2 text-sm font-semibold text-white hover:bg-white/10">Keluar</button>
          </> : null}
        </div>
      </header>
      {authUser ? (
        <div className="grid min-w-0 gap-5 md:grid-cols-[250px_minmax(0,1fr)]">
          <aside className="hidden self-start rounded-2xl border border-slate-200 bg-white p-3 shadow-sm md:sticky md:top-4 md:block md:max-h-[calc(100vh-2rem)] md:overflow-y-auto">
            {renderNavigation()}
          </aside>
          <section className="min-w-0">{renderContent()}</section>
          {drawerOpen ? (
            <div className="fixed inset-0 z-50 bg-slate-950/50 md:hidden" onClick={() => setDrawerOpen(false)}>
              <aside className="h-full w-[min(88vw,340px)] overflow-y-auto bg-white p-4 shadow-xl" onClick={(event) => event.stopPropagation()}>
                <div className="mb-4 flex items-center justify-between">
                  <h2 className="text-lg font-bold text-slate-900">Navigasi</h2>
                  <button type="button" onClick={() => setDrawerOpen(false)} className="rounded-lg border border-slate-300 px-3 py-2 text-sm">Tutup</button>
                </div>
                {renderNavigation(true)}
              </aside>
            </div>
          ) : null}
        </div>
      ) : <div className="py-8">{renderContent()}</div>}
    </main>
  );
}

function StatCard({ label, value, accent }: { label: string; value: string; accent: "blue" | "emerald" | "amber" | "violet" | "cyan" | "green" }) {
  const colorMap = {
    blue: "bg-blue-100 text-blue-800",
    emerald: "bg-emerald-100 text-emerald-800",
    amber: "bg-amber-100 text-amber-800",
    violet: "bg-violet-100 text-violet-800",
    cyan: "bg-cyan-100 text-cyan-800",
    green: "bg-green-100 text-green-800",
  };

  return (
    <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
      <p className="text-sm text-slate-600">{label}</p>
      <div className={`mt-2 inline-flex rounded-full px-2 py-1 text-xs font-semibold ${colorMap[accent]}`}>{value}</div>
    </div>
  );
}

function BarBox({ label, value, color }: { label: string; value: number | null; color: string }) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
      <p className="text-sm text-slate-600">{label}</p>
      {value === null ? <p className="mt-4 text-sm font-semibold text-slate-500">Belum tersedia</p> : <>
        <div className="mt-4 h-3 overflow-hidden rounded-full bg-slate-200">
          <div className={`${color} h-full rounded-full`} style={{ width: `${Math.max(0, Math.min(100, value))}%` }} />
        </div>
        <p className="mt-3 text-xl font-bold text-slate-900">{value.toFixed(0)}%</p>
      </>}
    </div>
  );
}
