import StudentAssessment from "@/components/student-assessment";

export default function StudentIdentityPage() {
  return <StudentAssessment initialView="identity" />;
}
