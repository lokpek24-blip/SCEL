import ResearcherDashboard from "@/components/researcher-dashboard";

export default function ResearcherPage() {
  return <ResearcherDashboard initialTab="dashboard" />;
}
