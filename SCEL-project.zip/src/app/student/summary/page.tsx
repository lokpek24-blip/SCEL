import StudentAssessment from "@/components/student-assessment";

export default function StudentSummaryPage() {
  return <StudentAssessment initialView="summary" />;
}
