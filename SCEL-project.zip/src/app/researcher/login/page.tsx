import ResearcherDashboard from "@/components/researcher-dashboard";

export default function ResearcherLoginPage() {
  return <ResearcherDashboard initialTab="dashboard" />;
}
