import ExcelJS from "exceljs";
import { ECO_ITEMS, SCIENCE_QUESTIONS, USABILITY_ITEMS } from "@/data/instruments";
import type { DemoStore } from "@/lib/demo-store";
import { getLatestAttempt, getResearchStore, getRaterScoreMap } from "@/lib/research-analytics";

type ExportValue = string | number | boolean | Date | null;
type ExportRow = Record<string, ExportValue>;
type ExportSheet = { headers: string[]; rows: ExportRow[] };
type DatasetName =
  | "Data_Peserta"
  | "SC_Respons"
  | "SC_Skor_R1"
  | "SC_Skor_R2"
  | "IRR"
  | "Eco_Religious"
  | "Usability"
  | "Validasi_Aiken"
  | "Wawancara_Guru"
  | "Observasi"
  | "SPSS_Eco_Wide"
  | "SPSS_Usability_Wide"
  | "SPSS_SC_Rater1_Wide"
  | "SPSS_SC_Rater2_Wide"
  | "SPSS_IRR_Wide"
  | "README_Data";

export type ResearchDatasets = Record<DatasetName, ExportSheet>;

const ratingDimensions = ["fluency", "flexibility", "originality"] as const;

function isoDate(value?: string) {
  if (!value) return null;
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? null : date;
}

function validScale(value: number | undefined, maximum: number) {
  return Number.isInteger(value) && value! >= 1 && value! <= maximum ? value! : null;
}

function getValidResponses(items: { id: number }[], responses: Record<number, number>, max: number) {
  return items.map(({ id }) => validScale(responses[id], max));
}

function totalAndMean(values: (number | null)[]) {
  const valid = values.filter((value): value is number => value !== null);
  return {
    total: valid.length ? valid.reduce((sum, value) => sum + value, 0) : null,
    mean: valid.length ? valid.reduce((sum, value) => sum + value, 0) / valid.length : null,
    percent: valid.length ? (valid.reduce((sum, value) => sum + value, 0) / valid.length / 5) * 100 : null,
  };
}

function makeSheet(headers: string[], rows: ExportRow[]): ExportSheet {
  return { headers, rows };
}

export function createResearchDatasets(input: DemoStore): ResearchDatasets {
  const store = getResearchStore(input);
  const participantById = new Map(store.participants.map((participant) => [participant.id, participant]));
  const attemptById = new Map(store.attempts.map((attempt) => [attempt.id, attempt]));
  const participants = store.participants;
  const attempts = store.attempts;
  const ecoHeaders = ECO_ITEMS.map((item) => `ER${String(item.id).padStart(2, "0")}`);
  const usabilityHeaders = USABILITY_ITEMS.map((item) => `US${String(item.id).padStart(2, "0")}`);
  const ecoWideRows: ExportRow[] = participants.map((participant) => {
    const attempt = getLatestAttempt(attempts, participant.id);
    const scores = attempt ? getValidResponses(ECO_ITEMS, attempt.ecoResponses, 5) : ECO_ITEMS.map(() => null);
    const metrics = totalAndMean(scores);
    return {
      participant_id: participant.id,
      kode_peserta: participant.participantCode,
      ...Object.fromEntries(ecoHeaders.map((header, index) => [header, scores[index]])),
      total_er: metrics.total,
      mean_er: metrics.mean,
    };
  });
  const usabilityWideRows: ExportRow[] = participants.map((participant) => {
    const attempt = getLatestAttempt(attempts, participant.id);
    const scores = attempt ? getValidResponses(USABILITY_ITEMS, attempt.usabilityResponses, 5) : USABILITY_ITEMS.map(() => null);
    const metrics = totalAndMean(scores);
    return {
      participant_id: participant.id,
      kode_peserta: participant.participantCode,
      ...Object.fromEntries(usabilityHeaders.map((header, index) => [header, scores[index]])),
      bagian_terbantu: attempt?.usabilityOpen.mostHelpful ?? "",
      kendala: attempt?.usabilityOpen.encounteredProblems ?? "",
      total_usability: metrics.total,
      mean_usability: metrics.mean,
      persentase_usability: metrics.percent,
    };
  });
  const raterScores = (raterId: "rater1" | "rater2") => store.raterScores
    .filter((score) => score.raterId === raterId)
    .flatMap((score) => {
      const attempt = attemptById.get(score.attemptId);
      const participant = attempt ? participantById.get(attempt.participantId) : undefined;
      const question = SCIENCE_QUESTIONS.find((item) => item.number === score.questionId);
      if (!attempt || !participant || !question) return [];
      return [{
        participant_id: participant.id,
        kode_peserta: participant.participantCode,
        nomor_soal: question.number,
        indikator: question.indicator,
        fluency: validScale(score.fluencyScore, 4),
        flexibility: validScale(score.flexibilityScore, 4),
        originality: validScale(score.originalityScore, 4),
        catatan_rater: score.notes,
        waktu_penilaian: isoDate(score.scoredAt),
      }];
    });
  const scResponseRows = attempts.flatMap((attempt) => {
    const participant = participantById.get(attempt.participantId);
    if (!participant) return [];
    return SCIENCE_QUESTIONS.map((question) => {
      const drawing = attempt.drawingResponses?.[question.number] ?? "";
      const extension = drawing.startsWith("data:image/png;") ? "png" : drawing.startsWith("data:image/jpeg;") ? "jpg" : "";
      return {
        participant_id: participant.id,
        kode_peserta: participant.participantCode,
        nomor_soal: question.number,
        indikator: question.indicator,
        jawaban_teks: attempt.scientificResponses[question.number] ?? "",
        file_gambar: drawing ? `${participant.participantCode}_Q${question.number}.${extension || "image"}` : "",
        waktu_simpan: isoDate(attempt.lastSavedAt),
        _attempt_id: attempt.id,
        _drawing_data: drawing,
      };
    });
  });

  const raterMap = getRaterScoreMap(store);
  const irrRows: ExportRow[] = [];
  const irrWideRows = participants.map((participant) => {
    const attempt = getLatestAttempt(attempts, participant.id);
    const row: ExportRow = { participant_id: participant?.id ?? "", kode_peserta: participant?.participantCode ?? "" };
    if (!attempt) return row;
    SCIENCE_QUESTIONS.forEach((question) => {
      ratingDimensions.forEach((dimension) => {
        const pair = raterMap.get(`${attempt.id}|${question.number}|${dimension}`);
        const base = `Q${String(question.number).padStart(2, "0")}_${dimension}`;
        row[`${base}_R1`] = pair?.r1 ?? null;
        row[`${base}_R2`] = pair?.r2 ?? null;
        row[`${base}_AGREE`] = pair?.r1 !== undefined && pair.r2 !== undefined ? pair.r1 === pair.r2 : null;
        if (pair?.r1 !== undefined && pair.r2 !== undefined) {
          irrRows.push({
            participant_id: attempt.participantId,
            kode_peserta: attempt.participantCode,
            nomor_soal: question.number,
            dimensi: dimension,
            skor_r1: pair.r1,
            skor_r2: pair.r2,
            status_kesepakatan: pair.r1 === pair.r2 ? "Sepakat" : "Tidak sepakat",
          });
        }
      });
    });
    return row;
  });

  const aikenRows = store.validationScores.map((score) => ({
    validator_id: score.validatorCode,
    domain_keahlian: score.validatorDomain,
    instrument_version: "SCEL-DC-v1.0-14Q",
    jenis_instrumen: /teologi|eco/i.test(score.validatorDomain) ? "Eco-Religious" : /media/i.test(score.validatorDomain) ? "Media digital" : /fisika|scel|materi/i.test(score.validatorDomain) ? "Scientific Creativity" : "",
    item_id: score.itemCode,
    aspek_penilaian: "",
    skor: validScale(score.score, 5),
    komentar: score.comments,
    tanggal_penilaian: isoDate(score.createdAt),
  }));
  const interviewRows = store.teacherInterviews.flatMap((interview) => {
    const responseEntries = Object.entries(interview.responses);
    return (responseEntries.length ? responseEntries : [["", ""]]).map(([question, answer]) => ({
      id_wawancara: interview.id,
      sekolah: interview.school,
      kode_guru: interview.teacherInitial,
      tanggal_wawancara: isoDate(interview.interviewDate),
      pertanyaan: question,
      jawaban: answer,
      catatan: interview.fieldNotes,
    }));
  });
  const observationRows = store.needsObservations.flatMap((observation) => {
    const entries = Object.entries(observation.observations);
    return (entries.length ? entries : [["", ""]]).map(([indicator, result]) => ({
      id_observasi: observation.id,
      sekolah: observation.school,
      tanggal_observasi: isoDate(observation.observationDate),
      observer: observation.observer,
      indikator: indicator,
      hasil_observasi: result,
      catatan: observation.discussionNotes,
      kesimpulan: observation.conclusion,
    }));
  });
  const spScWide = (raterId: "r1" | "r2") => participants.map((participant) => {
    const attempt = getLatestAttempt(attempts, participant.id);
    const row: ExportRow = { participant_id: participant?.id ?? "", kode_peserta: participant?.participantCode ?? "" };
    if (!attempt) return row;
    SCIENCE_QUESTIONS.forEach((question) => {
      ratingDimensions.forEach((dimension) => {
        const pair = raterMap.get(`${attempt.id}|${question.number}|${dimension}`);
        row[`Q${String(question.number).padStart(2, "0")}_${dimension}`] = pair?.[raterId] ?? null;
      });
    });
    return row;
  });
  const descriptionRows = [
    ["Data_Peserta", "Satu baris per peserta; waktu menggunakan ISO/date Excel."],
    ["SC_Respons", "Satu baris per peserta dan soal; jawaban teks utuh. Gambar rancangan tertanam di kolom file_gambar."],
    ["SC_Skor_R1 / SC_Skor_R2", "Skor rubric 1–4, dipisahkan berdasarkan rater; kosong tetap kosong."],
    ["IRR", "Hanya pasangan skor dimensi R1/R2 yang lengkap dan valid; skala 1–4."],
    ["Eco_Religious", "ER01–ER24 bernilai 1–5; nilai kosong dikecualikan dari total dan mean."],
    ["Usability", "US01–US15 bernilai 1–5; nilai kosong dikecualikan dari total, mean, dan persentase."],
    ["Validasi_Aiken", "Skor validator 1–5. Form demo tidak menyimpan jenis instrumen/aspek terpisah; kolom itu kosong jika tidak tersedia."],
    ["Wawancara_Guru / Observasi", "Satu baris per pertanyaan atau indikator, agar dapat difilter."],
    ["SPSS_*", "Wide format; skor hilang dibiarkan kosong (system-missing saat impor)."],
    ["Sumber", "Mode demo/localStorage. Baris demo bawaan tidak disertakan; tidak ada sinkronisasi Google Sheets aktif."],
  ].map(([dataset, definition]) => ({ dataset, definition }));

  return {
    Data_Peserta: makeSheet(
      ["participant_id", "kode_peserta", "nama_atau_inisial", "sekolah", "kelas", "waktu_mulai", "waktu_submit", "status_asesmen"],
      participants.map((participant) => {
        const attempt = getLatestAttempt(attempts, participant.id);
        return {
          participant_id: participant.id,
          kode_peserta: participant.participantCode,
          nama_atau_inisial: participant.nameOrInitial,
          sekolah: participant.school,
          kelas: participant.className,
          waktu_mulai: isoDate(attempt?.startedAt),
          waktu_submit: isoDate(attempt?.submittedAt),
          status_asesmen: attempt?.status ?? "belum dimulai",
        };
      }),
    ),
    SC_Respons: makeSheet(
      ["participant_id", "kode_peserta", "nomor_soal", "indikator", "jawaban_teks", "file_gambar", "waktu_simpan"],
      scResponseRows,
    ),
    SC_Skor_R1: makeSheet(
      ["participant_id", "kode_peserta", "nomor_soal", "indikator", "fluency", "flexibility", "originality", "catatan_rater", "waktu_penilaian"],
      raterScores("rater1"),
    ),
    SC_Skor_R2: makeSheet(
      ["participant_id", "kode_peserta", "nomor_soal", "indikator", "fluency", "flexibility", "originality", "catatan_rater", "waktu_penilaian"],
      raterScores("rater2"),
    ),
    IRR: makeSheet(
      ["participant_id", "kode_peserta", "nomor_soal", "dimensi", "skor_r1", "skor_r2", "status_kesepakatan"],
      irrRows,
    ),
    Eco_Religious: makeSheet(
      ["participant_id", "kode_peserta", ...ecoHeaders, "total_er", "mean_er"],
      ecoWideRows,
    ),
    Usability: makeSheet(
      ["participant_id", "kode_peserta", ...usabilityHeaders, "bagian_terbantu", "kendala", "total_usability", "mean_usability", "persentase_usability"],
      usabilityWideRows,
    ),
    Validasi_Aiken: makeSheet(
      ["validator_id", "domain_keahlian", "instrument_version", "jenis_instrumen", "item_id", "aspek_penilaian", "skor", "komentar", "tanggal_penilaian"],
      aikenRows,
    ),
    Wawancara_Guru: makeSheet(
      ["id_wawancara", "sekolah", "kode_guru", "tanggal_wawancara", "pertanyaan", "jawaban", "catatan"],
      interviewRows,
    ),
    Observasi: makeSheet(
      ["id_observasi", "sekolah", "tanggal_observasi", "observer", "indikator", "hasil_observasi", "catatan", "kesimpulan"],
      observationRows,
    ),
    SPSS_Eco_Wide: makeSheet(["participant_id", "kode_peserta", ...ecoHeaders], ecoWideRows.map((row): ExportRow => Object.fromEntries(
      ["participant_id", "kode_peserta", ...ecoHeaders].map((key) => [key, row[key]]),
    ))),
    SPSS_Usability_Wide: makeSheet(["participant_id", "kode_peserta", ...usabilityHeaders], usabilityWideRows.map((row): ExportRow => Object.fromEntries(
      ["participant_id", "kode_peserta", ...usabilityHeaders].map((key) => [key, row[key]]),
    ))),
    SPSS_SC_Rater1_Wide: makeSheet(["participant_id", "kode_peserta", ...SCIENCE_QUESTIONS.flatMap((question) => (["fluency", "flexibility", "originality"] as const).map((dimension) => `Q${String(question.number).padStart(2, "0")}_${dimension}`))], spScWide("r1")),
    SPSS_SC_Rater2_Wide: makeSheet(["participant_id", "kode_peserta", ...SCIENCE_QUESTIONS.flatMap((question) => (["fluency", "flexibility", "originality"] as const).map((dimension) => `Q${String(question.number).padStart(2, "0")}_${dimension}`))], spScWide("r2")),
    SPSS_IRR_Wide: makeSheet(["participant_id", "kode_peserta", ...SCIENCE_QUESTIONS.flatMap((question) => ratingDimensions.flatMap((dimension) => {
      const base = `Q${String(question.number).padStart(2, "0")}_${dimension}`;
      return [`${base}_R1`, `${base}_R2`, `${base}_AGREE`];
    }))], irrWideRows),
    README_Data: makeSheet(["dataset", "definition"], descriptionRows),
  };
}

function normalizeTextForCsv(value: ExportValue) {
  const text = value instanceof Date ? value.toISOString() : value === null ? "" : String(value);
  const safe = /^[=+\-@\t\r]/.test(text) ? `'${text}` : text;
  return `"${safe.replaceAll('"', '""')}"`;
}

export function createCsvContent(sheet: ExportSheet) {
  return [
    sheet.headers.map((header) => normalizeTextForCsv(header)).join(","),
    ...sheet.rows.map((row) => sheet.headers.map((header) => normalizeTextForCsv(row[header] ?? null)).join(",")),
  ].join("\r\n");
}

function getColumnWidth(header: string, rows: ExportRow[]) {
  const longest = rows.reduce((max, row) => Math.max(max, String(row[header] ?? "").length), header.length);
  return Math.min(Math.max(longest + 2, 12), ["jawaban_teks", "komentar", "bagian_terbantu", "kendala", "definition"].includes(header) ? 55 : 32);
}

export async function createResearchWorkbook(input: DemoStore, datasets: Record<string, ExportSheet> = createResearchDatasets(input)) {
  const workbook = new ExcelJS.Workbook();
  workbook.creator = "Digital Assessment SCEL";
  workbook.created = new Date();
  workbook.subject = "Dataset asesmen SCEL";

  Object.entries(datasets).forEach(([name, sheet]) => {
    const worksheet = workbook.addWorksheet(name);
    worksheet.columns = sheet.headers.map((header) => ({
      header,
      key: header,
      width: getColumnWidth(header, sheet.rows),
      style: ["participant_id", "kode_peserta", "validator_id", "kode_guru"].includes(header) ? { numFmt: "@" } : undefined,
    }));
    sheet.rows.forEach((row) => worksheet.addRow(sheet.headers.map((header) => row[header] ?? null)));
    worksheet.views = [{ state: "frozen", ySplit: 1 }];
    worksheet.autoFilter = {
      from: { row: 1, column: 1 },
      to: { row: Math.max(1, sheet.rows.length + 1), column: sheet.headers.length },
    };
    const header = worksheet.getRow(1);
    header.height = 24;
    header.font = { bold: true, color: { argb: "FFFFFFFF" } };
    header.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF1E3A5F" } };
    header.alignment = { vertical: "middle", wrapText: true };
    worksheet.eachRow((row, rowNumber) => {
      row.alignment = { vertical: "top", wrapText: rowNumber === 1 };
      row.eachCell((cell) => {
        if (cell.value instanceof Date) cell.numFmt = "yyyy-mm-dd hh:mm:ss";
        if (typeof cell.value === "number") cell.numFmt = "0.00";
      });
    });
  });

  const responseSheet = workbook.getWorksheet("SC_Respons");
  const responseDataset = datasets.SC_Respons;
  const imageColumn = responseDataset.headers.indexOf("file_gambar") + 1;
  if (responseSheet && imageColumn) {
    responseDataset.rows.forEach((row, index) => {
      const image = row._drawing_data;
      const match = typeof image === "string" ? image.match(/^data:image\/(png|jpeg);base64,(.+)$/) : null;
      if (!image || !match) return;
      const imageId = workbook.addImage({ base64: match[2], extension: match[1] === "jpeg" ? "jpeg" : "png" });
      const rowNumber = index + 2;
      responseSheet.getRow(rowNumber).height = 58;
      const imageCell = `${responseSheet.getColumn(imageColumn).letter}${rowNumber}`;
      responseSheet.addImage(imageId, `${imageCell}:${imageCell}`);
    });
  }

  return workbook.xlsx.writeBuffer();
}

export type { DatasetName, ExportSheet };
